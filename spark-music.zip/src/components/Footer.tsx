import { Facebook, Twitter, Instagram, Github, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-zinc-950 border-t border-emerald-500/10 pt-16 sm:pt-20 pb-10">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 sm:gap-12 mb-16 sm:mb-20">
          <div className="col-span-1 sm:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-emerald-500 rounded flex items-center justify-center">
                <div className="w-4 h-4 bg-black rounded-full" />
              </div>
              <span className="text-xl font-bold tracking-tighter text-white">SPARK <span className="text-emerald-500">MUSIC</span></span>
            </div>
            <p className="text-zinc-500 max-w-xs mb-8 text-sm sm:text-base">
              The world's largest music and audio platform, letting people discover and enjoy the greatest selection of music from the most diverse creator community on earth.
            </p>
            <div className="flex gap-4">
              <SocialLink icon={Facebook} />
              <SocialLink icon={Twitter} />
              <SocialLink icon={Instagram} />
              <SocialLink icon={Youtube} />
              <SocialLink icon={Github} />
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 sm:mb-6 text-sm uppercase tracking-widest">Platform</h4>
            <ul className="space-y-3 sm:space-y-4 text-zinc-500 text-sm">
              <li><a href="#" className="hover:text-emerald-500 transition-colors">About us</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Jobs</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Developers</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 sm:mb-6 text-sm uppercase tracking-widest">Support</h4>
            <ul className="space-y-3 sm:space-y-4 text-zinc-500 text-sm">
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Safety</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Terms of Use</a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 sm:mb-6 text-sm uppercase tracking-widest">Mobile</h4>
            <div className="flex flex-row sm:flex-col gap-3">
              <div className="flex-1 p-3 bg-zinc-900 border border-zinc-800 rounded-lg text-[10px] font-bold text-center cursor-pointer hover:bg-zinc-800 transition-colors border-emerald-500/10">
                APP STORE
              </div>
              <div className="flex-1 p-3 bg-zinc-900 border border-zinc-800 rounded-lg text-[10px] font-bold text-center cursor-pointer hover:bg-zinc-800 transition-colors border-emerald-500/10">
                GOOGLE PLAY
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-zinc-900 pt-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-zinc-600 text-[10px] sm:text-xs text-center md:text-left">
            © 2026 Spark Music Inc. All rights reserved. Made for creators, by creators.
          </p>
          <div className="flex gap-4 sm:gap-6 text-[9px] sm:text-[10px] uppercase font-bold tracking-widest text-zinc-600">
            <a href="#" className="hover:text-emerald-500">Cookie Policy</a>
            <a href="#" className="hover:text-emerald-500">Impressum</a>
            <a href="#" className="hover:text-emerald-500">Contact</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({ icon: Icon }: { icon: any }) {
  return (
    <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-500 hover:bg-emerald-500 hover:text-black transition-all">
      <Icon className="w-5 h-5" />
    </a>
  );
}
