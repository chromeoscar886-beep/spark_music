import { Check } from 'lucide-react';
import { motion } from 'motion/react';
import { Plan } from '../types';

const plans: Plan[] = [
  {
    id: 'free',
    name: 'Free',
    price: '$0',
    period: '/month',
    features: ['Upload up to 3 hours of audio', 'Basic stats', 'Ad-supported listening'],
    color: 'emerald'
  },
  {
    id: 'pro',
    name: 'Next Pro',
    price: '$12',
    period: '/month',
    features: ['Unlimited upload time', 'Advanced fan insights', 'Pro badge on profile', 'Replace audio files'],
    recommended: true,
    color: 'emerald'
  },
  {
    id: 'unlimited',
    name: 'Pro Unlimited',
    price: '$19',
    period: '/month',
    features: ['Mastering included (3/mo)', 'Highest bitrate streaming', 'Distribute to Spotify/Apple', 'Priority Support'],
    color: 'emerald'
  }
];

export default function Pricing() {
  return (
    <section id="plans" className="bg-black py-24 relative overflow-hidden">
       {/* Background glow */}
       <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-5xl h-full bg-emerald-500/5 blur-[100px] pointer-events-none" />

       <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16 md:mb-20">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Choose your plan</h2>
          <p className="text-zinc-500 max-w-2xl mx-auto text-sm sm:text-base">Elevate your music career with professional tools designed to help you grow your audience and monetize your craft.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className={`relative p-6 sm:p-8 rounded-2xl border ${
                plan.recommended 
                  ? 'bg-emerald-500/5 border-emerald-500 shadow-[0_0_40px_rgba(16,185,129,0.1)] scale-100 lg:scale-105 z-10' 
                  : 'bg-zinc-900/50 border-zinc-800'
              }`}
            >
              {plan.recommended && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-1 bg-emerald-500 text-black text-[10px] sm:text-xs font-bold rounded-full uppercase tracking-widest whitespace-nowrap">
                  Most Popular
                </div>
              )}

              <div className="mb-6 sm:mb-8">
                <h3 className="text-lg sm:text-xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl sm:text-4xl font-bold text-white">{plan.price}</span>
                  <span className="text-zinc-500 text-sm font-medium">{plan.period}</span>
                </div>
              </div>

              <ul className="space-y-3 sm:space-y-4 mb-8 sm:mb-10">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-start gap-3">
                    <div className="mt-1 flex-shrink-0 w-4 h-4 rounded-full bg-emerald-500/20 flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 text-emerald-500" />
                    </div>
                    <span className="text-zinc-400 text-xs sm:text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                className={`w-full py-3.5 sm:py-4 rounded-xl font-bold text-sm transition-all active:scale-95 ${
                  plan.recommended 
                    ? 'bg-emerald-500 text-black hover:bg-emerald-400 shadow-lg shadow-emerald-500/20' 
                    : 'bg-zinc-800 text-white hover:bg-zinc-700'
                }`}
              >
                Get Started
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
