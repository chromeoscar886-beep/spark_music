import { Play, Mic2, Music, Sparkles, History, ChevronLeft, ChevronRight, Pause, ShieldCheck, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Track } from '../types';
import { usePlayer } from '../contexts/PlayerContext';

const SLIDE_DURATION = 6000; // 6 seconds per slide

const slides = [
  {
    image: '/carousel_mainpage/1.jpg',
    fallback: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=1920&auto=crop',
    title: 'Connect on Spark Music',
    description: 'Discover, stream, and share a constantly expanding mix of music from emerging and major artists around the world. All in one place.',
    badge: '🏆 THE FUTURE OF DISCOVERY'
  },
  {
    image: '/carousel_mainpage/2.jpg',
    fallback: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=1920&auto=crop',
    title: 'Discover Fresh Soundwaves',
    description: 'Immerse yourself in weekly updated playlists curated by professional DJs and music editors across electronic, rock, and alternative hip-hop.',
    badge: '🎠 EXPLORE CONTINUOUSLY'
  },
  {
    image: '/carousel_mainpage/3.jpg',
    fallback: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=1920&auto=crop',
    title: 'Immersive Spatial Stage',
    description: 'Experience state-of-the-art high-fidelity spatial acoustics and custom audio staging that brings raw concert energy straight to your ears.',
    badge: '✨ HIGH-FIDELITY SOUND'
  },
  {
    image: '/carousel_mainpage/4.jpg',
    fallback: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=1920&auto=crop',
    title: 'Empower Independent Acts',
    description: 'Support independent creators directly. Spark ensures that over 90% of local streaming revenue goes right back to developing indie artists.',
    badge: '🌱 ARTIST-FIRST SPACE'
  },
  {
    image: '/carousel_mainpage/5.jpg',
    fallback: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?q=80&w=1920&auto=crop',
    title: 'Intimate Live Lounges',
    description: 'Unlock back-stage access to acoustic recordings, exclusive artist interviews, live studio mixtapes, and raw unplugged bootlegs.',
    badge: '📻 EXCLUSIVE STREAMING'
  }
];

export default function Hero() {
  const navigate = useNavigate();
  const { setTrack } = usePlayer();
  const [lastTrack, setLastTrack] = useState<Track | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoplay, setIsAutoplay] = useState(true);
  const [progress, setProgress] = useState(0);
  const [dataSaver, setDataSaver] = useState(() => localStorage.getItem('data_saver') === 'true');

  const toggleDataSaver = () => {
    const newValue = !dataSaver;
    setDataSaver(newValue);
    localStorage.setItem('data_saver', String(newValue));
    window.dispatchEvent(new Event('datasaver-change'));
  };

  useEffect(() => {
    const handleValueChange = () => {
      setDataSaver(localStorage.getItem('data_saver') === 'true');
    };
    window.addEventListener('datasaver-change', handleValueChange);
    return () => window.removeEventListener('datasaver-change', handleValueChange);
  }, []);

  // Fallback state for images that fail to load from local `/carousel_mainpage/` path
  const [imageSources, setImageSources] = useState<string[]>(slides.map(s => s.image));

  const handleResume = (track: Track) => {
    setTrack(track);
    navigate(`/track/${track.id}`, { state: { track } });
  };

  useEffect(() => {
    const history = localStorage.getItem('spark_history');
    if (history) {
      try {
        const parsed = JSON.parse(history);
        if (parsed.length > 0) {
          setLastTrack(parsed[0]);
        }
      } catch (e) {
        console.error('Failed to load history', e);
      }
    }
  }, []);

  // Set up the progress bar and slide indexing
  useEffect(() => {
    if (!isAutoplay) return;

    setProgress(0);
    const intervalTime = 50;
    const step = (intervalTime / SLIDE_DURATION) * 100;

    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          setCurrentIndex(prev => (prev + 1) % slides.length);
          return 0;
        }
        return p + step;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [currentIndex, isAutoplay]);

  const handlePrev = () => {
    setIsAutoplay(false);
    setProgress(0);
    setCurrentIndex(prev => (prev - 1 + slides.length) % slides.length);
  };

  const handleNext = () => {
    setIsAutoplay(false);
    setProgress(0);
    setCurrentIndex(prev => (prev + 1) % slides.length);
  };

  const handleDotClick = (index: number) => {
    setIsAutoplay(false);
    setProgress(0);
    setCurrentIndex(index);
  };

  const handleImageError = (index: number) => {
    console.log(`Local image for slide ${index + 1} not found at ${slides[index].image}. Loading fallback asset...`);
    setImageSources(prev => {
      const copy = [...prev];
      copy[index] = slides[index].fallback;
      return copy;
    });
  };

  return (
    <div id="home-hero" className="relative group/hero overflow-hidden bg-black text-white h-[480px] sm:h-[550px] md:h-[620px] lg:h-[680px] w-full flex flex-col justify-end select-none">
      
      {/* Dynamic Slide Background Images with Zoom & Crossfade Effect */}
      <div className="absolute inset-0 z-0 bg-black overflow-hidden">
        {slides.map((slide, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              i === currentIndex ? 'opacity-55 scale-100' : 'opacity-0 scale-105 pointer-events-none'
            }`}
            style={{ transitionProperty: 'opacity, transform' }}
          >
            <img
              src={imageSources[i]}
              alt={slide.title}
              onError={() => handleImageError(i)}
              className="w-full h-full object-cover transition-transform duration-[6000ms] ease-out scale-105"
              referrerPolicy="no-referrer"
              style={{
                transform: i === currentIndex ? 'scale(1.0)' : 'scale(1.05)',
              }}
            />
          </div>
        ))}
        {/* Layered gradients for deep aesthetic contrast and text block readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/45 to-black/85 z-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/25 z-10" />
      </div>

      {/* Hero Interactive Text & Action Block Container */}
      <div className="container mx-auto px-4 sm:px-6 relative z-20 pb-12 sm:pb-20 h-full flex flex-col justify-end">
        <div className="max-w-3xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="space-y-4 md:space-y-6"
            >
              {/* Slide Custom Promo Tag */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 text-[10px] sm:text-xs font-mono uppercase tracking-widest leading-none">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{slides[currentIndex].badge}</span>
              </div>
              
              {/* Animated Slide Heading */}
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-none text-white drop-shadow-md">
                {slides[currentIndex].title.includes("Spark Music") ? (
                  <>Connect on <span className="text-emerald-500 italic">Spark Music</span></>
                ) : (
                  slides[currentIndex].title
                )}
              </h1>
              
              {/* Slide Narrative Subdescription */}
              <p className="text-sm sm:text-base md:text-lg text-zinc-300 max-w-xl md:max-w-2xl leading-relaxed font-normal">
                {slides[currentIndex].description}
              </p>

              {/* Action Buttons Layer */}
              <div className="flex flex-col sm:flex-row flex-wrap gap-3 pt-3 md:pt-4">
                {lastTrack ? (
                  <button 
                    onClick={() => handleResume(lastTrack)}
                    className="w-full sm:w-auto px-6 py-3 bg-emerald-500 text-black text-sm font-bold rounded-lg flex items-center justify-center gap-2.5 hover:bg-emerald-400 transition-all shadow-[0_4px_24px_rgba(16,185,129,0.25)] active:scale-95"
                  >
                    <History className="w-4 h-4 shrink-0" />
                    <span className="truncate">Resume: {lastTrack.musicname}</span>
                  </button>
                ) : (
                  <button 
                    onClick={() => document.getElementById('trends')?.scrollIntoView({ behavior: 'smooth' })}
                    className="w-full sm:w-auto px-6 py-3 bg-emerald-500 text-black text-sm font-bold rounded-lg flex items-center justify-center gap-2.5 hover:bg-emerald-400 transition-all shadow-[0_4px_24px_rgba(16,185,129,0.25)] active:scale-95"
                  >
                    <Mic2 className="w-4 h-4 shrink-0" />
                    <span>Start Streaming Now</span>
                  </button>
                )}
                
                <button 
                  onClick={() => document.getElementById('trends')?.scrollIntoView({ behavior: 'smooth' })}
                  className="w-full sm:w-auto px-6 py-3 bg-zinc-900/80 text-white text-sm font-bold rounded-lg border border-zinc-800/80 flex items-center justify-center gap-2.5 hover:bg-zinc-800 hover:border-zinc-700 backdrop-blur-sm transition-all active:scale-95"
                >
                  <Play className="w-4 h-4 fill-current shrink-0" />
                  <span>Listen to Trending</span>
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Manual Slide Navigation Overlay Arrows */}
      <button 
        onClick={handlePrev}
        className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-30 w-10 h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-white/15 border border-white/5 hover:border-white/10 text-zinc-400 hover:text-white backdrop-blur-md outline-none transition-all active:scale-90 pointer-events-auto opacity-0 group-hover/hero:opacity-100 cursor-pointer"
        title="Previous Slide"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>
      <button 
        onClick={handleNext}
        className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-30 w-10 h-10 rounded-full flex items-center justify-center bg-black/40 hover:bg-white/15 border border-white/5 hover:border-white/10 text-zinc-400 hover:text-white backdrop-blur-md outline-none transition-all active:scale-90 pointer-events-auto opacity-0 group-hover/hero:opacity-100 cursor-pointer"
        title="Next Slide"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Bottom Timeline Indicator & Dot Selection Tray */}
      <div className="absolute bottom-0 left-0 w-full z-30 bg-gradient-to-t from-black/80 to-transparent pt-6 pb-4">
        <div className="container mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
          
          {/* Active Carousel Navigation Dots */}
          <div className="flex items-center gap-2">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => handleDotClick(i)}
                className="relative h-2 md:h-2.5 outline-none rounded-full overflow-hidden transition-all duration-300 bg-white/20 hover:bg-white/40 cursor-pointer"
                style={{
                  width: i === currentIndex ? '36px' : '10px'
                }}
                title={`Go to Slide ${i + 1}`}
              >
                {/* Autoplay loading filler for active DOT */}
                {i === currentIndex && (
                  <div 
                    className="absolute left-0 top-0 h-full bg-gradient-to-r from-emerald-500 via-green-400 to-yellow-300 transition-all duration-50 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                    style={{ 
                      width: `${progress}%`,
                      transition: progress === 0 ? 'none' : 'width 50ms linear'
                    }}
                  />
                )}
              </button>
            ))}
          </div>

          {/* Right-aligned Trays: Data Saver & Playback Controllers */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Data Saver Mode Toggle Button */}
            <button
              onClick={toggleDataSaver}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-[10px] font-mono uppercase tracking-wider transition-all select-none cursor-pointer border ${
                dataSaver 
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-400 hover:bg-amber-500/30 font-bold shadow-[0_0_12px_rgba(245,158,11,0.2)]' 
                  : 'bg-zinc-900/60 border-zinc-800/60 text-zinc-400 hover:border-zinc-700/60 hover:text-white'
              }`}
              title={dataSaver ? "Disable Data Saver Mode (Load Ultra High Quality)" : "Enable Data Saver Mode (Load Fast Thumbnails)"}
            >
              <Zap className={`w-3 h-3 ${dataSaver ? 'text-amber-400 fill-current' : 'text-zinc-500'}`} />
              <span>Data Saver: {dataSaver ? "On" : "Off"}</span>
            </button>

            {/* Mini Playback State Badge and Quick Toggle */}
            <button 
              onClick={() => setIsAutoplay(!isAutoplay)}
              className="flex items-center gap-1.5 px-2 py-1 rounded bg-zinc-900/60 border border-zinc-800/60 hover:border-zinc-700/60 transition-all text-zinc-400 hover:text-white hover:bg-zinc-800/60 text-[10px] font-mono uppercase tracking-wider shrink-0 cursor-pointer"
              title={isAutoplay ? "Pause Autoplay" : "Resume Autoplay"}
            >
              {isAutoplay ? (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                  <span>Autoplay On</span>
                </>
              ) : (
                <>
                  <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 shrink-0" />
                  <span>Paused</span>
                </>
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Top Slider Boundary Progress Bar with Creative Ambient Light Gradient */}
      {isAutoplay && (
        <div className="absolute top-0 left-0 w-full h-[4px] bg-white/10 z-40 overflow-visible">
          {/* Main loader bar */}
          <div 
            className="h-full bg-gradient-to-r from-emerald-500 via-emerald-400 via-green-400 to-yellow-300 relative rounded-r-full shadow-[0_0_12px_rgba(16,185,129,0.85),_0_0_24px_rgba(234,179,8,0.65)]"
            style={{ 
              width: `${progress}%`,
              transition: progress === 0 ? 'none' : 'width 50ms linear'
            }}
          >
            {/* Bright, pulsing pointer light element at the tip of the bar */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3.5 h-3.5 rounded-full bg-yellow-300 filter blur-[2px] opacity-100 animate-pulse pointer-events-none" style={{ marginRight: '-7px' }} />
          </div>
          {/* Blurry ambient backlight bleed directly beneath */}
          <div 
            className="absolute top-0 left-0 h-[20px] bg-gradient-to-r from-emerald-500/25 via-emerald-400/20 to-yellow-300/15 blur-md pointer-events-none rounded-b-full"
            style={{ 
              width: `${progress}%`,
              transition: progress === 0 ? 'none' : 'width 50ms linear'
            }}
          />
        </div>
      )}

    </div>
  );
}
