import { usePlayer } from '../contexts/PlayerContext';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, 
  Heart, Repeat, MoreHorizontal 
} from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import MusicImage from './MusicImage';

export default function GlobalPlayerBar() {
  const { 
    currentTrack, playing, togglePlay, volume, setVolume, 
    muted, setMuted, played, duration, seekTo, navigateToTrack,
    isLiked, toggleLike, activeColor
  } = usePlayer();
  
  const location = useLocation();
  const navigate = useNavigate();

  // Hide on PlayerPage as it has its own extensive UI
  if (!currentTrack || location.pathname.startsWith('/track/')) return null;

  const formatTime = (seconds: number) => {
    const date = new Date(seconds * 1000);
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds().toString().padStart(2, '0');
    return `${mm}:${ss}`;
  };

  const color = activeColor || '#10b981'; // Dynamic color from hook with emerald fallback

  return (
    <div className="fixed bottom-0 left-0 w-full z-[100] bg-black/95 backdrop-blur-xl border-t border-white/5 px-2 xs:px-4 md:px-6 py-2 md:py-3 flex items-center justify-between gap-1.5 xs:gap-3 md:gap-4 select-none cursor-default">
      <div 
        className="flex items-center gap-1.5 xs:gap-2.5 md:gap-4 w-auto max-w-[32%] xs:max-w-[40%] md:w-1/4 md:min-w-[200px] cursor-pointer overflow-hidden min-w-0 shrink-0"
        onClick={() => navigate(`/track/${currentTrack.id}`)}
      >
        <MusicImage track={currentTrack} className="w-7 h-7 xs:w-9 xs:h-9 md:w-12 md:h-12 rounded object-cover flex-shrink-0" />
        <div className="overflow-hidden min-w-0">
          <div className="text-[10px] xs:text-[11px] md:text-sm font-bold truncate">{currentTrack.musicname}</div>
          <div 
            onClick={(e) => { e.stopPropagation(); navigate(`/artist/${encodeURIComponent(currentTrack.channel_name)}`); }}
            className="text-[9px] xs:text-[10px] md:text-xs text-zinc-500 truncate transition-colors"
            style={{ color: `${color}dd` }}
          >
            {currentTrack.channel_name}
          </div>
        </div>
        <button 
          onClick={(e) => { e.stopPropagation(); toggleLike(); }}
          className={`ml-1 md:ml-2 transition-all active:scale-90 flex-shrink-0 ${isLiked ? 'text-rose-500' : 'text-zinc-500'}`}
          style={{ color: isLiked ? '#f43f5e' : `${color}aa` }}
        >
          <Heart className={`w-3 h-3 xs:w-3.5 xs:h-3.5 md:w-4 md:h-4 ${isLiked ? 'fill-current' : ''}`} />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center gap-0.5 md:gap-1 min-w-0">
        <div className="flex items-center gap-1.5 xs:gap-3 md:gap-6 mb-1">
          <button className="text-zinc-400 hover:text-white transition-colors hidden md:block"><Repeat className="w-4 h-4" /></button>
          <button onClick={(e) => { e.stopPropagation(); navigateToTrack(-1); }} className="text-zinc-200 hover:text-white active:scale-90 transition-all">
            <SkipBack className="w-3.5 h-3.5 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current" />
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); togglePlay(); }}
            className="w-7.5 h-7.5 xs:w-9 xs:h-9 md:w-10 md:h-10 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg shrink-0"
          >
            {playing ? <Pause className="w-3 h-3 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current" /> : <Play className="w-3 h-3 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current ml-0.5" />}
          </button>
          <button onClick={(e) => { e.stopPropagation(); navigateToTrack(1); }} className="text-zinc-200 hover:text-white active:scale-90 transition-all">
            <SkipForward className="w-3.5 h-3.5 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current" />
          </button>
          <button className="text-zinc-400 hover:text-white transition-colors hidden md:block"><MoreHorizontal className="w-4 h-4" /></button>
        </div>
        
        <div className="w-full flex items-center gap-2 md:gap-3 py-1">
          <span className="text-[10px] font-mono text-zinc-500 w-7 md:w-10 text-right">{formatTime(played * duration)}</span>
          <div className="flex-1 h-4 md:h-6 flex items-center relative group">
            <input 
              type="range" min={0} max={0.999999} step="any"
              value={played}
              onChange={(e) => seekTo(parseFloat(e.target.value))}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
              style={{ touchAction: 'none' }}
            />
            {/* Visual Bar */}
            <div className="w-full h-1.5 md:h-1 bg-zinc-800 rounded-full relative overflow-hidden">
               <div className="absolute left-0 top-0 h-full rounded-full" style={{ width: `${played * 100}%`, backgroundColor: color }} />
            </div>
            {/* Handle */}
            <div className="absolute top-1/2 -translate-y-1/2 w-3.5 h-3.5 md:w-3 md:h-3 bg-white rounded-full shadow-xl md:opacity-0 md:group-hover:opacity-100 transition-opacity z-10 pointer-events-none" style={{ left: `${played * 100}%`, marginLeft: '-7px' }} />
          </div>
          <span className="text-[10px] font-mono text-zinc-500 w-7 md:w-10">{formatTime(duration)}</span>
        </div>
      </div>

      <div className="items-center gap-4 w-1/4 justify-end hidden md:flex">
        <div className="flex items-center gap-2">
          <button onClick={() => setMuted(!muted)} className="text-zinc-400 hover:text-white transition-colors">
            {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <div className="w-20 h-1 bg-zinc-800 rounded-full relative">
             <input 
              type="range" min={0} max={1} step="any"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
             />
             <div className="absolute left-0 top-0 h-full rounded-full" style={{ width: `${volume * 100}%`, backgroundColor: color }} />
          </div>
        </div>
      </div>
    </div>
  );
}
