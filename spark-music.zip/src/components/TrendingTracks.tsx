import { useEffect, useState } from 'react';
import { Play, Heart, MessageCircle, Repeat, Share2, Globe, X, Facebook, Twitter, Instagram, Clock, Eye, Music2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { Track, TrendingResponse, formatViews } from '../types';
import { usePlayer } from '../contexts/PlayerContext';
import { musicApi, getApiBaseUrl } from '../services/api';
import MusicImage from './MusicImage';

export default function TrendingSection() {
  const navigate = useNavigate();
  const { currentTrack, setTrack, setAllTracks } = usePlayer();
  const [data, setData] = useState<TrendingResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [configUrl, setConfigUrl] = useState(() => {
    return localStorage.getItem('spark_api_base_url') || getApiBaseUrl();
  });

  const saveAndRetry = () => {
    localStorage.setItem('spark_api_base_url', configUrl.trim());
    window.location.reload();
  };

  const handleTrackClick = (track: Track) => {
    setTrack(track);
    navigate(`/track/${track.id}`, { state: { track } });
  };

  useEffect(() => {
    const fetchTrending = async () => {
      setLoading(true);
      setError(null);
      try {
        const json = await musicApi.getMainTrends();
        
        if (json.status === "success") {
          setData(json);
          setAllTracks(json.data);
        } else {
          throw new Error('API returned unsuccessful status');
        }
      } catch (err) {
        console.error('API Error:', err);
        setError('Failed to connect to the music server. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchTrending();
  }, []);

  if (loading) return (
    <div className="py-20 flex flex-col items-center justify-center bg-black min-h-[400px]">
      <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin mb-4" />
      <div className="text-emerald-500 font-mono tracking-widest animate-pulse uppercase">Fetching Live Data...</div>
    </div>
  );

  if (error) return (
    <div className="py-20 flex flex-col items-center justify-center bg-zinc-950 text-center px-6 border-y border-emerald-500/10">
      <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mb-6">
        <Globe className="w-8 h-8" />
      </div>
      <h3 className="text-xl font-bold text-white mb-2">Network Connection Setup</h3>
      <p className="text-zinc-400 max-w-md text-xs leading-relaxed mb-6">
        Failed to connect to the music server. This usually happens because your browser blocks mixed-content (HTTPS requesting HTTP) or the local database server is offline. Verify your Spark Music API Base Address below:
      </p>

      <div className="w-full max-w-md bg-black/45 border border-white/5 p-5 rounded-2xl mb-6 text-left space-y-3">
        <div>
          <label className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest block mb-1">
            Spark Music API Base URL Address
          </label>
          <input 
            type="text"
            value={configUrl}
            onChange={(e) => setConfigUrl(e.target.value)}
            className="w-full bg-zinc-900 border border-white/5 rounded-xl py-2.5 px-3.5 text-zinc-300 placeholder:text-zinc-650 text-xs font-mono focus:outline-none focus:border-emerald-500/30 transition-all font-sans"
            placeholder="e.g. http://localhost/sparkmusicapi"
          />
        </div>
        <p className="text-[10px] text-zinc-500 leading-normal font-sans">
          💡 If your database is hosted on a specific port or custom IP address (e.g. <code className="font-mono text-zinc-400">http://127.0.0.1:8888/sparkmusicapi</code>), enter it above and save.
        </p>
      </div>

      <div className="flex gap-3">
        <button 
          onClick={saveAndRetry}
          className="px-6 py-2.5 bg-emerald-500 text-black font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-emerald-400 transition-colors cursor-pointer"
        >
          Save & Retry Connection
        </button>
        <button 
          onClick={() => window.location.reload()}
          className="px-5 py-2.5 bg-zinc-900 text-zinc-300 font-medium text-xs uppercase tracking-wider rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer border border-white/5"
        >
          Refresh Page
        </button>
      </div>
    </div>
  );

  return (
    <section id="trends" className="bg-zinc-950 py-20">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 text-emerald-500 mb-3">
              <Globe className="w-4 h-4 animate-pulse" />
              <span className="text-xs font-bold tracking-widest uppercase bg-emerald-500/10 px-2 py-0.5 rounded">
                Trend for: {data?.country}
              </span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Most Trending Today</h2>
            <p className="text-zinc-500 mt-2">Showing top {data?.count} tracks from your API.</p>
          </div>
        </div>

        <div className="space-y-2.5 max-w-7xl mx-auto">
          {/* Spotify-style Header Row */}
          <div className="hidden sm:grid grid-cols-[50px_1.5fr_1fr_120px_100px_100px] items-center gap-4 px-4 py-3 text-zinc-500 font-extrabold text-[11px] uppercase tracking-wider border-b border-white/5 mb-3 select-none">
            <div className="text-center">#</div>
            <div>Title</div>
            <div>Artist</div>
            <div className="flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" />
              <span>Views</span>
            </div>
            <div className="flex items-center gap-1 justify-center">
              <Heart className="w-3.5 h-3.5 text-zinc-500" />
              <span>Likes</span>
            </div>
            <div className="text-right">Rank</div>
          </div>

          {/* Dynamic Row for active playing track */}
          {currentTrack && (
            <div 
              onClick={() => handleTrackClick(currentTrack)}
              className="group flex sm:grid sm:grid-cols-[50px_1.5fr_1fr_120px_100px_100px] items-center gap-4 p-2 sm:p-3 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent border border-emerald-500/30 hover:border-emerald-500/50 cursor-pointer shadow-lg shadow-emerald-500/5 relative mb-4 transition-all duration-300"
            >
              {/* Outer pulsing aura */}
              <div className="absolute inset-0 bg-emerald-500/[0.02] animate-pulse pointer-events-none rounded-2xl" />

              {/* Animated Soundwave Equalizer */}
              <div className="w-10 sm:w-auto text-center flex items-center justify-center shrink-0">
                <div className="flex gap-[2px] items-end justify-center h-4 w-5">
                  {[1, 2, 3].map((val) => (
                    <motion.span
                      key={val}
                      className="w-[3px] bg-emerald-400 rounded-full"
                      animate={{ height: ["4px", "14px", "4px"] }}
                      transition={{
                        repeat: Infinity,
                        duration: 0.5 + val * 0.15,
                        ease: "easeInOut"
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Title & Cover Image */}
              <div className="flex items-center gap-3.5 min-w-0 flex-1 relative z-10">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-zinc-900 border border-emerald-500/30 shrink-0 relative shadow-[0_0_12px_rgba(16,185,129,0.2)]">
                  <MusicImage 
                    track={currentTrack} 
                    alt={currentTrack.musicname}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="min-w-0 pr-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[8px] font-black uppercase tracking-wider bg-emerald-500 text-black px-1 rounded-sm leading-none py-0.5">NOW RUNNING</span>
                  </div>
                  <h3 className="font-extrabold text-sm sm:text-base text-emerald-400 group-hover:text-emerald-300 transition-colors duration-200 truncate leading-snug mt-1.5">
                    {currentTrack.musicname}
                  </h3>
                  {/* Mobile artist name displayed under the title */}
                  <p className="sm:hidden text-xs font-medium text-zinc-400 truncate mt-0.5 max-w-[180px]">
                    {currentTrack.artistname}
                  </p>
                </div>
              </div>

              {/* Artist/Channel (Desktop only) */}
              <div className="hidden sm:block min-w-0 relative z-10">
                <p className="text-sm font-semibold text-zinc-200 truncate group-hover:text-zinc-100 transition-colors duration-200">
                  {currentTrack.artistname}
                </p>
              </div>

              {/* Views Count */}
              <div className="hidden sm:flex items-center gap-1.5 min-w-0 text-emerald-300 font-mono text-xs relative z-10 font-bold">
                <span>{formatViews(currentTrack.musicviews)}</span>
              </div>

              {/* Likes Count */}
              <div className="hidden sm:flex items-center justify-center gap-1.5 min-w-0 text-rose-400/80 font-mono text-xs text-center pr-2 relative z-10">
                <Heart className="w-3.5 h-3.5 text-rose-500/50" />
                <span>{currentTrack.musiclikes ? (isNaN(parseInt(currentTrack.musiclikes)) ? currentTrack.musiclikes : `${(parseInt(currentTrack.musiclikes) / 100).toFixed(1)}k`) : '0k'}</span>
              </div>

              {/* Right rank badge & mobile details */}
              <div className="ml-auto sm:ml-0 flex items-center gap-3 shrink-0 justify-end relative z-10">
                <span className="text-[10px] font-black font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-md uppercase tracking-wide">
                  LIVE
                </span>
              </div>
            </div>
          )}

          {data?.data && data.data.length > 0 ? (
            data.data.map((track, i) => (
              <TrackCard 
                key={`${track.id}-${i}`} 
                track={track} 
                index={i} 
                onClick={() => handleTrackClick(track)}
              />
            ))
          ) : (
            <div className="py-20 text-center text-zinc-650 font-medium">
              No trends data available currently from the music API.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function TrackCard({ track, index, onClick }: { track: Track; index: number; onClick: () => void; key?: string }) {
  const formattedLikes = track.musiclikes ? (
    isNaN(parseInt(track.musiclikes)) ? track.musiclikes : `${(parseInt(track.musiclikes) / 100).toFixed(1)}k`
  ) : '0k';

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ delay: index * 0.03, duration: 0.4 }}
      className="group flex sm:grid sm:grid-cols-[50px_1.5fr_1fr_120px_100px_100px] items-center gap-4 p-2 sm:p-3 rounded-2xl hover:bg-zinc-900/50 border border-transparent hover:border-white/5 cursor-pointer transition-all duration-300 relative"
      onClick={onClick}
    >
      {/* Position Indicator */}
      <div className="w-10 sm:w-auto text-center flex items-center justify-center shrink-0">
        <span className="text-xs font-black font-mono text-zinc-500 group-hover:opacity-0 transition-all duration-200">
          {index + 1}
        </span>
        <div className="absolute opacity-0 group-hover:opacity-100 transition-all duration-200 text-emerald-400">
          <Play className="w-4 h-4 fill-emerald-400" />
        </div>
      </div>

      {/* Title & Cover Image */}
      <div className="flex items-center gap-3.5 min-w-0 flex-1">
        <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-zinc-900 border border-white/10 shrink-0 relative group-hover:border-emerald-500/20 transition-all duration-300">
          <MusicImage 
            track={track} 
            alt={track.musicname}
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="min-w-0 pr-1">
          <h3 className="font-bold text-sm sm:text-base text-zinc-100 group-hover:text-emerald-400 transition-colors duration-200 truncate leading-snug">
            {track.musicname}
          </h3>
          {/* Mobile artist name displayed under the title */}
          <p className="sm:hidden text-xs font-medium text-zinc-500 truncate mt-0.5 max-w-[180px]">
            {track.artistname}
          </p>
        </div>
      </div>

      {/* Artist/Channel (Desktop only) */}
      <div className="hidden sm:block min-w-0">
        <p className="text-sm font-semibold text-zinc-400 truncate group-hover:text-zinc-200 transition-colors duration-200">
          {track.artistname}
        </p>
      </div>

      {/* Views Count */}
      <div className="hidden sm:flex items-center gap-1.5 min-w-0 text-zinc-400 font-mono text-xs">
        <span>{formatViews(track.musicviews)}</span>
      </div>

      {/* Likes Count */}
      <div className="hidden sm:flex items-center justify-center gap-1.5 min-w-0 text-rose-400/80 font-mono text-xs text-center pr-2">
        <Heart className="w-3.5 h-3.5 text-rose-500/50" />
        <span>{formattedLikes}</span>
      </div>

      {/* Right rank badge & mobile details */}
      <div className="ml-auto sm:ml-0 flex items-center gap-3 shrink-0 justify-end">
        {/* Mobile display of views */}
        <span className="sm:hidden text-xs font-mono text-zinc-500 font-bold">
          {formatViews(track.musicviews)}
        </span>
        
        <span className="text-[10px] font-black font-mono text-emerald-500/80 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md uppercase tracking-wide">
          #{index + 1}
        </span>
      </div>
    </motion.div>
  );
}

