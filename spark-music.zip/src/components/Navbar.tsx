import { Search, Bell, MoreHorizontal, User, Upload, Menu, X, Play, Music, Loader2, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { usePlayer } from '../contexts/PlayerContext';
import { useAuth } from '../contexts/AuthContext';
import { Track } from '../types';
import { musicApi } from '../services/api';
import MusicImage from './MusicImage';
import Logo from './Logo';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Track[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const navigate = useNavigate();
  const { setTrack, setAllTracks } = usePlayer();
  const { isAuthenticated, logout, user } = useAuth();
  const searchRef = useRef<HTMLDivElement>(null);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const debounceTimer = setTimeout(async () => {
      if (query.trim().length > 1) {
        setIsLoading(true);
        try {
          const data = await musicApi.search(query);
          let tracks: Track[] = [];
          if (Array.isArray(data)) {
            tracks = data;
          } else if (data && data.status === 'success' && Array.isArray(data.data)) {
            tracks = data.data;
          } else if (data && Array.isArray(data.data)) {
            tracks = data.data;
          } else if (data && Array.isArray(data.results)) {
            tracks = data.results;
          }
          
          if (tracks.length > 0) {
            setResults(tracks);
            setShowResults(true);
          } else {
            setResults([]);
          }
        } catch (error) {
          console.error('Search error:', error);
          setResults([]);
        } finally {
          setIsLoading(false);
        }
      } else {
        setResults([]);
        setShowResults(false);
      }
    }, 400);

    return () => clearTimeout(debounceTimer);
  }, [query]);

  const handleTrackSelect = (track: Track) => {
    setTrack(track);
    setAllTracks(results.length > 0 ? results : [track]);
    setShowResults(false);
    setQuery('');
    navigate(`/track/${track.id}`, { state: { track } });
  };

  return (
    <nav className="sticky top-0 z-[60] w-full bg-black/90 backdrop-blur-md border-b border-emerald-500/20 px-4 h-15 flex items-center justify-between">
      <div className="flex items-center gap-4 lg:gap-8 flex-1">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group cursor-pointer shrink-0">
          <Logo variant="full" className="h-9 sm:h-11 md:h-12 w-auto transition-transform group-hover:scale-105" />
        </Link>

        <div className="hidden lg:flex items-center gap-6 shrink-0">
          <Link to="/" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">Home</Link>
          <Link to="/feed" className="text-sm font-medium text-white hover:text-emerald-500 transition-colors">Feed</Link>
          {isAuthenticated && (
            <Link to="/library" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">Library</Link>
          )}
        </div>

        {/* Dynamic Search Bar */}
        <div className="flex-1 max-w-xl relative hidden sm:block" ref={searchRef}>
          <div className="relative group">
            <input 
              type="text" 
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => query.trim().length > 1 && setShowResults(true)}
              placeholder="Search for tracks..." 
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg py-2 pl-4 pr-10 text-sm text-zinc-200 placeholder:text-zinc-500 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 transition-all"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              {isLoading ? (
                <Loader2 className="w-4 h-4 text-emerald-500 animate-spin" />
              ) : (
                <Search className="w-4 h-4 text-zinc-500 group-focus-within:text-emerald-500 transition-colors" />
              )}
            </div>
          </div>

          {/* Search Results Dropdown */}
          <AnimatePresence>
            {showResults && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute top-full left-0 right-0 mt-2 bg-zinc-950 border border-white/5 rounded-xl shadow-2xl overflow-hidden z-[100]"
              >
                <div className="max-h-[400px] overflow-y-auto p-2 space-y-1">
              {results.length > 0 ? (
                    results.map((track, i) => (
                      <button
                        key={`${track.id}-${i}`}
                        onClick={() => handleTrackSelect(track)}
                        className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors group text-left"
                      >
                        <div className="w-10 h-10 rounded overflow-hidden flex-shrink-0 bg-zinc-900 bg-center">
                          <MusicImage track={track} alt="" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-bold text-white truncate uppercase tracking-tight group-hover:text-emerald-500 transition-colors">{track.musicname}</div>
                          <div className="text-xs text-zinc-500 truncate">{track.channel_name || track.artistname}</div>
                        </div>
                        <Play className="w-4 h-4 text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    ))
                  ) : (
                    <div className="py-8 text-center text-zinc-500">
                      <Music className="w-8 h-8 mx-auto mb-2 opacity-20" />
                      <p className="text-sm">No results found for "{query}"</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-3 lg:gap-5 ml-4">
        {isAuthenticated ? (
          <>
            <button className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold bg-emerald-500 text-black hover:bg-emerald-400 transition-all active:scale-95 shadow-lg shadow-emerald-500/20">
              <Upload className="w-4 h-4" />
              Upload
            </button>
            
            <div className="hidden md:flex items-center gap-4 text-zinc-400">
              <button className="hover:text-emerald-500 transition-colors"><Bell className="w-5 h-5" /></button>
            </div>

            {/* Profile/Menu Trigger */}
            <div className="flex items-center gap-2 relative">
               <div 
                onClick={() => {
                  if (window.innerWidth < 1024) {
                    setIsMenuOpen(true);
                  } else {
                    setShowProfileMenu(!showProfileMenu);
                  }
                }}
                className="h-8 w-8 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center cursor-pointer hover:bg-emerald-500/40 transition-colors shrink-0"
              >
                <User className="w-4 h-4 text-emerald-500" />
              </div>
              
              <AnimatePresence>
                {showProfileMenu && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full right-0 mt-2 w-48 bg-zinc-950 border border-white/5 rounded-xl shadow-2xl overflow-hidden z-[100] hidden lg:block"
                  >
                    <div className="p-3 border-b border-white/5">
                      <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Signed in as</p>
                      <p className="text-sm font-bold text-white truncate">{user?.username}</p>
                    </div>
                    <div className="p-1">
                      <button 
                        onClick={() => {
                          setShowProfileMenu(false);
                          navigate('/profile');
                        }}
                        className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors text-white text-sm font-medium"
                      >
                        <User className="w-4 h-4 text-emerald-500" />
                        My Profile
                      </button>
                      <button 
                        onClick={logout}
                        className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors text-red-500 text-sm font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="lg:hidden p-2 text-zinc-400 hover:text-emerald-500 hover:bg-zinc-900 rounded-lg transition-colors ml-1"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </>
        ) : (
          <div className="flex items-center gap-2">
            <Link 
              to="/login"
              className="hidden sm:block text-sm font-bold text-zinc-400 hover:text-white transition-colors px-2"
            >
              Sign In
            </Link>
            <Link 
              to="/register"
              className="hidden sm:block px-4 py-2 bg-emerald-500 text-black rounded-lg text-sm font-bold hover:bg-emerald-400 transition-all active:scale-95 shadow-lg shadow-emerald-500/20"
            >
              Get Started
            </Link>
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="sm:hidden p-2 text-zinc-400 hover:text-emerald-500"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        )}
      </div>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100]"
              onClick={() => setIsMenuOpen(false)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-[300px] bg-zinc-950 z-[110] shadow-2xl border-l border-emerald-500/20 p-5 flex flex-col"
            >
              <div className="flex items-center justify-between mb-8">
                <Link to="/" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 shrink-0">
                  <Logo variant="full" className="h-8 w-auto" />
                </Link>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 hover:bg-zinc-900 rounded-lg text-zinc-400 transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* User Section in Sidebar */}
              {isAuthenticated && (
                <div className="mb-8 p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-transparent border border-emerald-500/20">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-black font-bold">
                      {user?.username?.[0]?.toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-emerald-500 uppercase tracking-widest text-[9px]">Logged in as</p>
                      <p className="text-sm font-bold text-white truncate">{user?.username}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-6 flex-1 overflow-y-auto">
                {/* Search in Sidebar (More Prominent) */}
                <div className="relative group">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2">
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 text-emerald-500 animate-spin" />
                    ) : (
                      <Search className="w-4 h-4 text-zinc-500" />
                    )}
                  </div>
                  <input 
                    type="text" 
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onFocus={() => query.trim().length > 1 && setShowResults(true)}
                    placeholder="Search music..." 
                    className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl py-3.5 pl-10 pr-4 text-sm text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-all"
                  />
                </div>

                {/* Mobile Search Results */}
                <AnimatePresence>
                  {showResults && (
                    <motion.div 
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-zinc-900/30 rounded-xl overflow-hidden border border-white/5"
                    >
                      <div className="max-h-[300px] overflow-y-auto p-2 space-y-1">
                        {results.length > 0 ? (
                          results.map((track, i) => (
                            <button
                              key={`${track.id}-${i}`}
                              onClick={() => {
                                handleTrackSelect(track);
                                setIsMenuOpen(false);
                              }}
                              className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-white/5 transition-colors group text-left border-b border-white/5 last:border-0"
                            >
                              <div className="w-12 h-12 rounded overflow-hidden flex-shrink-0 bg-zinc-900 bg-center">
                                <MusicImage track={track} alt="" className="w-full h-full object-cover" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="text-sm font-bold text-white truncate uppercase tracking-tight group-hover:text-emerald-500 transition-colors">{track.musicname}</div>
                                <div className="text-xs text-zinc-500 truncate">{track.channel_name}</div>
                              </div>
                            </button>
                          ))
                        ) : (
                          <div className="py-4 text-center text-[10px] text-zinc-600">No results found</div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <nav className="flex flex-col gap-2">
                  <MobileLink to="/" label="Home" icon={<Music className="w-4 h-4" />} onClick={() => setIsMenuOpen(false)} />
                  <MobileLink to="/feed" label="Social Feed" icon={<Search className="w-4 h-4" />} onClick={() => setIsMenuOpen(false)} />
                  {isAuthenticated && (
                    <MobileLink to="/library" label="Your Library" icon={<MoreHorizontal className="w-4 h-4" />} onClick={() => setIsMenuOpen(false)} />
                  )}
                </nav>

                {isAuthenticated && (
                  <div className="pt-6 border-t border-white/5 space-y-2">
                    <button 
                      onClick={() => {
                        navigate('/profile');
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors text-zinc-400 font-bold text-sm"
                    >
                      <User className="w-4 h-4" />
                      Account Settings
                    </button>
                    <button 
                      onClick={() => {
                        logout();
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-red-500/10 transition-colors text-red-500 font-bold text-sm"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>

              <div className="mt-8 pt-6 border-t border-white/5">
                {!isAuthenticated ? (
                  <div className="flex flex-col gap-3">
                    <Link 
                      to="/login"
                      onClick={() => setIsMenuOpen(false)}
                      className="w-full flex items-center justify-center py-4 rounded-xl bg-zinc-900 border border-white/5 text-white font-bold text-sm"
                    >
                      Sign In
                    </Link>
                    <Link 
                      to="/register"
                      onClick={() => setIsMenuOpen(false)}
                      className="w-full flex items-center justify-center py-4 rounded-xl bg-emerald-500 text-black font-bold text-sm shadow-lg shadow-emerald-500/20"
                    >
                      Create Account
                    </Link>
                  </div>
                ) : (
                  <button className="w-full flex items-center justify-center gap-2 py-4 rounded-xl bg-emerald-500 text-black font-bold text-sm shadow-lg shadow-emerald-500/20">
                    <Upload className="w-4 h-4" />
                    Upload Music
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </nav>
  );
}

function MobileLink({ to, label, icon, active = false, onClick }: { to: string; label: string; icon: React.ReactNode; active?: boolean; onClick: () => void }) {
  return (
    <Link 
      to={to} 
      onClick={onClick}
      className={`flex items-center gap-4 text-base font-bold transition-all px-4 py-3.5 rounded-xl ${active ? 'bg-emerald-500/10 text-emerald-500' : 'text-zinc-400 hover:text-white hover:bg-zinc-900'}`}
    >
      {icon}
      {label}
    </Link>
  );
}

