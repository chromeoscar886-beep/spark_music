import React from 'react';

interface LogoProps {
  variant?: 'full' | 'icon';
  className?: string;
  id?: string;
}

export default function Logo({ variant = 'full', className = 'h-8', id }: LogoProps) {
  // Common definitions used in both versions
  const defs = (
    <defs>
      {/* Brilliant, clean lime-green gradient for the music note */}
      <linearGradient id="cleanLimeGrad" x1="0%" y1="100%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#22c55e" />
        <stop offset="100%" stopColor="#a3e635" />
      </linearGradient>

      {/* Sharp text-specific gradient */}
      <linearGradient id="sharpTextGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#a3e635" />
        <stop offset="100%" stopColor="#22c55e" />
      </linearGradient>
      
      {/* Subtle glow filter targeted directly for the spark */}
      <filter id="subtleSparkGlow" x="-10%" y="-10%" width="120%" height="120%">
        <feGaussianBlur stdDeviation="4" result="blur" />
        <feComposite in="SourceGraphic" in2="blur" operator="over" />
      </filter>
    </defs>
  );

  // The artwork group containing the note, spark, and music bubbles
  const artworkGroup = (
    <g transform="translate(30, 20)">
      {/* Musical note stems and dynamic flag */}
      <path d="M140,40 L220,15 L220,55 L140,80 Z" fill="url(#cleanLimeGrad)" />
      <rect x="130" y="40" width="15" height="170" fill="url(#cleanLimeGrad)" rx="2" />
      <rect x="210" y="15" width="15" height="150" fill="url(#cleanLimeGrad)" rx="2" />
      
      {/* Left note head (angled beautifully) */}
      <g transform="translate(137, 210) rotate(-25)">
        <ellipse cx="0" cy="0" rx="42" ry="28" fill="url(#cleanLimeGrad)" />
        <ellipse cx="-10" cy="-5" rx="15" ry="8" fill="#ffffff" opacity="0.3" />
      </g>

      {/* Right note head */}
      <g transform="translate(217, 165) rotate(-25)">
        <ellipse cx="0" cy="0" rx="42" ry="28" fill="url(#cleanLimeGrad)" />
        <ellipse cx="-10" cy="-5" rx="15" ry="8" fill="#ffffff" opacity="0.3" />
      </g>

      {/* Radiant sparkling element on the note stem */}
      <g transform="translate(115, -15)" filter="url(#subtleSparkGlow)">
        <path d="M 0,-30 L 10,-10 L 32,-18 L 18,5 L 38,20 L 12,18 L 10,40 L -6,15 L -28,24 L -12,2 L -32,-12 L -6,-6 Z" fill="#ccff00" />
        <polygon points="0,-15 5,-5 18,-9 9,2 20,10 6,9 5,22 -3,8 -16,13 -6,1 -18,-6 -3,-3" fill="#ffffff" />
      </g>
      
      {/* Ambient particles representing sound expansion */}
      <circle cx="270" cy="40" r="6" fill="#a3e635" />
      <circle cx="295" cy="90" r="4" fill="#22c55e" />
      <circle cx="75" cy="50" r="8" fill="#a3e635" />
      <circle cx="60" cy="110" r="5" fill="#22c55e" />
    </g>
  );

  if (variant === 'icon') {
    // Return a square viewport containing only the high-quality music/spark art
    return (
      <svg
        id={id}
        xmlns="http://www.w3.org/2000/svg"
        viewBox="100 10 300 300"
        className={className}
        fill="none"
      >
        {defs}
        <g transform="translate(40, 40)">
          {artworkGroup}
        </g>
      </svg>
    );
  }

  // Otherwise, return the full branding logo including SPARK MUSIC and the wave
  return (
    <svg
      id={id}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 950 400"
      className={className}
      fill="none"
    >
      {defs}
      <g transform="translate(40, 40)">
        {artworkGroup}

        {/* SPARK heading typography */}
        <text 
          x="360" 
          y="170" 
          fontFamily="'Montserrat', 'Helvetica Neue', Arial, sans-serif" 
          fontSize="120" 
          fontWeight="900" 
          fill="url(#sharpTextGrad)" 
          letterSpacing="-2"
        >
          SPARK
        </text>
        
        {/* MUSIC subtitle typography */}
        <text 
          x="365" 
          y="250" 
          fontFamily="'Montserrat', 'Helvetica Neue', Arial, sans-serif" 
          fontSize="55" 
          fontWeight="700" 
          fill="#10b981" /* Adjusted to pure emerald for high legibility in dark mode theme */
          letterSpacing="14"
        >
          MUSIC
        </text>
        
        {/* Seamless soundwave ribbon linking the text blocks */}
        <path 
          d="M365,300 C 460,280 500,320 590,300 C 680,280 730,310 820,295" 
          stroke="url(#sharpTextGrad)" 
          strokeWidth="8" 
          strokeLinecap="round" 
          fill="none" 
        />
              
        <circle cx="835" cy="294" r="5" fill="#22c55e" />
      </g>
    </svg>
  );
}
