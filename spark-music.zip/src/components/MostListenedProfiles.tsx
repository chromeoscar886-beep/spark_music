import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  Flame, Trophy, Sparkles, ChevronLeft, ChevronRight, AlertCircle, RefreshCw 
} from 'lucide-react';
import { MostListenedArtist } from '../types';
import { musicApi } from '../services/api';

// Realistic fallbacks in case localhost PHP server is down or during initial configuration
const FALLBACK_ARTISTS: MostListenedArtist[] = [
  {
    artist_name: "Ahmed Saad",
    profile_image: "https://lh3.googleusercontent.com/rLWvGWmDnKudFul92O7dULNXP5wEZqDd5yTQaiVcNb7XdHEKMV3NUfe4O3NyO44OlG6Udle3e7oAPzAERg=w180-h180-l90-rj"
  },
  {
    artist_name: "Amr Diab",
    profile_image: "https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=300&auto=format&fit=crop"
  },
  {
    artist_name: "Wegz",
    profile_image: "https://images.unsplash.com/photo-1549417229-aa67d3263c09?q=80&w=300&auto=format&fit=crop"
  },
  {
    artist_name: "Sherine",
    profile_image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop"
  },
  {
    artist_name: "Tamer Hosny",
    profile_image: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=80&w=300&auto=format&fit=crop"
  },
  {
    artist_name: "Nancy Ajram",
    profile_image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=300&auto=format&fit=crop"
  },
  {
    artist_name: "Ruby",
    profile_image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300&auto=format&fit=crop"
  }
];

// Single artist card item, memoized for optimal performance
const ArtistCard = React.memo(({ 
  artist, 
  index, 
  onSelect 
}: { 
  artist: MostListenedArtist; 
  index: number; 
  onSelect: (name: string) => void;
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);

  // Check if first artist
  const isFirst = index === 0;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      onClick={() => onSelect(artist.artist_name)}
      className={`relative flex-shrink-0 snap-start select-none cursor-pointer group flex flex-col items-center justify-center transition-all duration-300 ${
        isFirst 
          ? 'w-[150px] sm:w-[170px] bg-gradient-to-b from-emerald-500/10 to-zinc-900/40 p-5 rounded-3xl border border-emerald-500/30 hover:border-emerald-400 hover:shadow-2xl hover:shadow-emerald-500/10' 
          : 'w-[125px] sm:w-[135px] hover:bg-zinc-900/40 p-3 sm:p-4 rounded-3xl border border-transparent hover:border-white/5'
      }`}
    >
      {/* Featured Badge for first artist */}
      {isFirst && (
        <div className="absolute -top-2 px-3 py-1 bg-gradient-to-r from-emerald-500 to-green-400 text-black text-[9px] font-black rounded-full uppercase tracking-wider flex items-center gap-1 shadow-lg shadow-emerald-500/20 z-10 animate-pulse">
          <Trophy className="w-2.5 h-2.5" />
          Featured
        </div>
      )}

      {/* Profile Image Frame */}
      <div className="relative">
        <div 
          className={`rounded-full overflow-hidden shadow-2xl transition-all duration-500 group-hover:shadow-emerald-500/10 ease-out shrink-0 ${
            isFirst 
              ? 'w-24 h-24 sm:w-28 h-28 border-2 border-emerald-500 ring-4 ring-emerald-500/10' 
              : 'w-20 h-20 sm:w-22 h-22 border border-zinc-800'
          } group-hover:scale-105 duration-300`}
        >
          {/* Skeleton or dynamic gradient during load */}
          {!imageLoaded && !imageError && (
            <div className="absolute inset-0 bg-zinc-900 animate-pulse flex items-center justify-center rounded-full">
              <Sparkles className="w-4 h-4 text-zinc-700 animate-spin" />
            </div>
          )}

          <img
            src={imageError ? 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=150&auto=format&fit=crop' : artist.profile_image}
            alt={artist.artist_name}
            loading="lazy"
            referrerPolicy="no-referrer"
            className={`w-full h-full object-cover transition-all duration-700 ${
              imageLoaded ? 'scale-100 blur-0' : 'scale-105 blur-lg'
            }`}
            onLoad={() => setImageLoaded(true)}
            onError={() => {
              setImageLoaded(true);
              setImageError(true);
            }}
          />
        </div>

        {/* Floating Rank circle */}
        <div className={`absolute bottom-0 right-0 w-6 h-6 rounded-full flex items-center justify-center font-black text-[10px] font-mono shadow-md ${
          isFirst 
            ? 'bg-emerald-500 text-black' 
            : 'bg-zinc-900 text-zinc-400 border border-white/5'
        }`}>
          #{index + 1}
        </div>
      </div>

      {/* Artist Name & Metas */}
      <span className={`mt-3 font-bold text-center w-full truncate text-zinc-100 group-hover:text-emerald-400 transition-colors uppercase select-none ${
        isFirst ? 'text-sm sm:text-base font-extrabold pb-0.5' : 'text-xs pb-0'
      }`}>
        {artist.artist_name}
      </span>

      <span className="text-[9px] font-bold tracking-widest text-zinc-500 uppercase select-none">
        {isFirst ? "Top Lead" : "Verified Artist"}
      </span>
    </motion.div>
  );
});

ArtistCard.displayName = 'ArtistCard';

interface MostListenedProfilesProps {
  country?: string;
}

export default function MostListenedProfiles({ country }: MostListenedProfilesProps) {
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  const [artists, setArtists] = useState<MostListenedArtist[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const fetchMostListened = async () => {
    setLoading(true);
    setFetchError(null);
    setIsOffline(false);
    try {
      const countryParam = country === 'GLOBAL' ? undefined : country;
      const response = await musicApi.getMostListenedArtists(countryParam);
      if (response && response.status === 'success' && Array.isArray(response.data)) {
        // Only keep artists with valid artist_name and profile_image
        const validData = response.data.filter(a => a.artist_name && a.profile_image);
        if (validData.length > 0) {
          setArtists(validData);
        } else {
          setArtists(FALLBACK_ARTISTS);
          setIsOffline(true);
        }
      } else {
        setArtists(FALLBACK_ARTISTS);
        setIsOffline(true);
      }
    } catch (err) {
      console.warn("Failed fetching live artists data, substituting with fallback catalog:", err);
      setArtists(FALLBACK_ARTISTS);
      setIsOffline(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMostListened();
  }, [country]);

  // Performance optimized navigation callback
  const handleSelectArtist = useMemo(() => {
    return (name: string) => {
      navigate(`/artist/${encodeURIComponent(name)}`);
    };
  }, [navigate]);

  // Scroll controls for desktop convenience
  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const { scrollLeft, clientWidth } = scrollContainerRef.current;
      const scrollAmount = clientWidth * 0.7;
      scrollContainerRef.current.scrollTo({
        left: direction === 'left' ? scrollLeft - scrollAmount : scrollLeft + scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="relative w-full bg-zinc-950/40 border border-white/5 rounded-[32px] p-6 mb-8 backdrop-blur-3xl overflow-hidden shadow-[inset_0_1px_1px_rgba(255,255,255,0.05),0_12px_40px_rgba(0,0,0,0.6)]">
      {/* Glow highlight inside */}
      <div className="absolute top-0 left-10 w-[200px] h-[200px] bg-emerald-500/5 rounded-full blur-[100px] pointer-events-none" />

      {/* Header section with styling inspired by international apps */}
      <div className="flex items-center justify-between mb-6 z-10 relative">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl">
            <Flame className="w-5 h-5 text-emerald-400 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white flex items-center gap-2 tracking-tight uppercase">
              Most Listened Artists
              <span className="text-xs font-black text-emerald-500 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full font-mono uppercase tracking-widest hidden sm:inline-block">LIVE STATS</span>
            </h2>
            <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mt-0.5">
              Top listened profiles this week
            </p>
          </div>
        </div>

        {/* Carousel buttons */}
        <div className="flex items-center gap-2">
          {isOffline && (
            <button 
              onClick={fetchMostListened}
              className="p-1.5 rounded-lg text-emerald-500 hover:text-emerald-400 bg-emerald-500/10 border border-emerald-500/10 hover:border-emerald-500/30 transition-all flex items-center gap-1.5 text-[9px] font-bold font-mono tracking-wider mr-2"
              title="Refresh local cache"
            >
              <RefreshCw className="w-3 h-3" />
              Refresh
            </button>
          )}

          <button
            onClick={() => scroll('left')}
            className="w-10 h-10 rounded-2xl bg-zinc-900/80 border border-white/5 flex items-center justify-center hover:border-zinc-700 hover:text-emerald-400 transition-all text-zinc-400 active:scale-90"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="w-10 h-10 rounded-2xl bg-zinc-900/80 border border-white/5 flex items-center justify-center hover:border-zinc-700 hover:text-emerald-400 transition-all text-zinc-400 active:scale-90"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Connection notice banner */}
      {isOffline && (
        <div className="mb-4 bg-emerald-950/20 border border-emerald-500/20 rounded-2xl p-3 flex items-center gap-3 text-xs text-zinc-400">
          <AlertCircle className="w-4 h-4 text-emerald-400 flex-shrink-0 animate-bounce" />
          <span>
            Showing premium curated artists. Start your local SparkMusic API to stream real-time listenership database details.
          </span>
        </div>
      )}

      {/* Artists scroll layer */}
      <div 
        ref={scrollContainerRef}
        className="flex items-center gap-4 sm:gap-6 overflow-x-auto scrollbar-none snap-x snap-mandatory py-2 touch-pan-x"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {loading ? (
          // SKELETON PLACEHOLDER LOADER
          Array.from({ length: 7 }).map((_, idx) => (
            <div 
              key={idx} 
              className={`flex-shrink-0 flex flex-col items-center justify-center animate-pulse ${
                idx === 0 ? 'w-[150px] sm:w-[170px] p-5 border border-zinc-800 rounded-3xl' : 'w-[125px] sm:w-[135px] p-3'
              }`}
            >
              <div className={`rounded-full bg-zinc-900/80 ${
                idx === 0 ? 'w-24 h-24 sm:w-28 h-28' : 'w-20 h-20 sm:w-22 h-22'
              }`} />
              <div className="h-4 bg-zinc-900/80 rounded-full w-2/3 mt-3" />
              <div className="h-3 bg-zinc-900/80 rounded-full w-1/2 mt-1.5" />
            </div>
          ))
        ) : (
          artists.map((artist, index) => (
            <ArtistCard 
              key={`${artist.artist_name}-${index}`}
              artist={artist}
              index={index}
              onSelect={handleSelectArtist}
            />
          ))
        )}
      </div>
    </div>
  );
}
