import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Clock, History, Trash2, X, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Track } from '../types';
import { usePlayer } from '../contexts/PlayerContext';
import MusicImage from './MusicImage';

export default function RecentlyPlayed() {
  const navigate = useNavigate();
  const { setTrack, setAllTracks } = usePlayer();
  const [history, setHistory] = useState<Track[]>([]);
  const [showConfirm, setShowConfirm] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('spark_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setHistory(parsed);
        // We don't setAllTracks here normally because it might conflict with home page trends
        // but for context it's fine if someone clicks play
      } catch (e) {
        console.error('Failed to parse history', e);
      }
    }
  }, []);

  const handleTrackClick = (track: Track) => {
    setTrack(track);
    navigate(`/track/${track.id}`, { state: { track } });
  };

  const clearHistory = () => {
    localStorage.removeItem('spark_history');
    localStorage.removeItem('spark_last_track_id');
    setHistory([]);
    setShowConfirm(false);
  };

  if (history.length === 0) return null;

  return (
    <section className="bg-black py-12 md:py-16 border-b border-white/5 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between mb-8 md:mb-10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 md:w-10 md:h-10 bg-emerald-500/10 rounded-full flex items-center justify-center text-emerald-500">
              <History className="w-4 h-4 md:w-5 md:h-5" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">Pick up where you left off</h2>
              <p className="text-zinc-500 text-[10px] md:text-sm">Your recent listening history</p>
            </div>
          </div>
          
          <button 
            onClick={() => setShowConfirm(true)}
            className="flex items-center gap-1.5 md:gap-2 px-3 md:px-4 py-1.5 md:py-2 bg-zinc-900 hover:bg-red-500/10 text-zinc-400 hover:text-red-500 transition-all rounded-lg border border-zinc-800"
            title="Clear History"
          >
            <Trash2 className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-[10px] md:text-sm font-medium uppercase tracking-wider">Clear</span>
          </button>
        </div>

        <div className="flex gap-4 md:gap-6 overflow-x-auto pb-6 scrollbar-hide snap-x">
          {history.map((track, i) => (
            <motion.div
              key={`${track.id}-${i}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => handleTrackClick(track)}
              className="flex-shrink-0 w-36 sm:w-40 md:w-48 group cursor-pointer snap-start"
            >
              <div className="relative aspect-square rounded-xl overflow-hidden mb-3 shadow-lg group-hover:shadow-emerald-500/10 transition-all">
                <MusicImage 
                  track={track} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Creative Hover Overlay */}
                <div className="absolute inset-0 bg-black/75 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center backdrop-blur-[2px]">
                  <div className="flex flex-col items-center gap-2">
                    {/* Spinning ring wrapper */}
                    <div className="relative w-12 h-12 flex items-center justify-center">
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 6, ease: "linear" }}
                        className="absolute inset-x-0 inset-y-0 rounded-full border border-dashed border-emerald-500/30"
                      />
                      <div className="absolute inset-0 rounded-full bg-emerald-500/10 animate-ping duration-[1400ms]" />
                      
                      <div className="w-9 h-9 bg-emerald-500 text-black rounded-full flex items-center justify-center shadow-xl transform scale-95 group-hover:scale-105 transition-all duration-300 relative z-10 cursor-pointer">
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      </div>
                    </div>

                    {/* Compact equalizer visualization */}
                    <div className="flex gap-0.5 items-end justify-center h-3 w-6 mt-1">
                      {[
                        { delay: 0.1, duration: 0.5 },
                        { delay: 0.3, duration: 0.8 },
                        { delay: 0.0, duration: 0.6 }
                      ].map((eq, idx) => (
                        <motion.span
                          key={idx}
                          className="w-[2.5px] bg-emerald-400 rounded-full"
                          animate={{ height: ["3px", "10px", "3px"] }}
                          transition={{
                            repeat: Infinity,
                            duration: eq.duration,
                            delay: eq.delay,
                            ease: "easeInOut"
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div className="overflow-hidden">
                <h3 className="text-white font-bold text-xs sm:text-sm truncate transition-all duration-300 group-hover:translate-x-1 group-hover:text-emerald-400 uppercase tracking-tight">
                  {track.musicname}
                </h3>
              </div>
              <p className="text-zinc-500 text-[10px] sm:text-xs truncate transition-colors duration-300 group-hover:text-zinc-400">{track.artistname}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirm && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowConfirm(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-zinc-900 border border-white/10 p-8 rounded-2xl max-w-sm w-full shadow-2xl"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center text-red-500 shrink-0">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Clear History?</h3>
                  <p className="text-zinc-400 text-sm">This will remove all your recently played tracks. This action cannot be undone.</p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 px-6 py-3 bg-zinc-800 hover:bg-zinc-700 text-white font-bold rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={clearHistory}
                  className="flex-1 px-6 py-3 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl transition-colors"
                >
                  Yes, Clear
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
