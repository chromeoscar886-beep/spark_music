import { useState, useEffect } from 'react';
import { Track } from '../types';

export function getYouTubeVideoId(track: Track): string | null {
  // Try extracting from musiclink first
  if (track.musiclink) {
    const regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = track.musiclink.match(regExp);
    if (match && match[2] && match[2].length === 11) {
      return match[2];
    }
  }
  // Try parsing from musicimg if it is already a YouTube image URL
  if (track.musicimg) {
    const regExp = /(?:vi|v)\/([a-zA-Z0-9_-]{11})/;
    const match = track.musicimg.match(regExp);
    if (match && match[1]) {
      return match[1];
    }
    
    // Fallback for ytimg patterns
    if (track.musicimg.includes('ytimg.com') || track.musicimg.includes('youtube.com')) {
      const parts = track.musicimg.split('/');
      const viIndex = parts.indexOf('vi');
      if (viIndex !== -1 && parts[viIndex + 1]) {
        return parts[viIndex + 1].split('?')[0];
      }
    }
  }
  return null;
}

interface MusicImageProps {
  track: Track;
  className?: string;
  alt?: string;
  referrerPolicy?: React.HTMLAttributeReferrerPolicy;
}

export default function MusicImage({ track, className = '', alt = '', referrerPolicy = 'no-referrer' }: MusicImageProps) {
  const [sources, setSources] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [dataSaver, setDataSaver] = useState(() => localStorage.getItem('data_saver') === 'true');

  useEffect(() => {
    const handleValueChange = () => {
      setDataSaver(localStorage.getItem('data_saver') === 'true');
    };
    window.addEventListener('datasaver-change', handleValueChange);
    return () => window.removeEventListener('datasaver-change', handleValueChange);
  }, []);

  useEffect(() => {
    const videoId = getYouTubeVideoId(track);
    const originalImg = track.musicimg;

    if (videoId) {
      if (dataSaver) {
        // Data Saver mode: directly start loading standard/low resolution variants to save internet bandwidth
        setSources([
          `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,     // Medium fidelity (320x180)
          `https://img.youtube.com/vi/${videoId}/default.jpg`,       // Default low resolution (120x90)
          originalImg,                                               // Original image URL
        ]);
      } else {
        // High fidelity prioritized fallback chain
        setSources([
          `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`, // Ultra high resolution (1080p)
          `https://img.youtube.com/vi/${videoId}/sddefault.jpg`,     // Standard high definition (640x480)
          `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,     // High fidelity (480x360)
          `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,     // Medium fidelity (320x180)
          `https://img.youtube.com/vi/${videoId}/default.jpg`,       // Default low resolution (120x90)
          originalImg,                                               // Original url representation
        ]);
      }
    } else {
      // Non-YouTube custom music images
      setSources([originalImg]);
    }
    setCurrentIndex(0);
  }, [track, dataSaver]);

  const handleLoad = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    const img = e.currentTarget;
    // YouTube returns a 120x90 image (placeholder) with code 200 instead of 404 for missing high-res images.
    // We treat images with naturalWidth <= 120 as a fallback trigger so we go to the next resolution layout.
    if (img.naturalWidth > 0 && img.naturalWidth <= 120 && currentIndex < sources.length - 1) {
      // Skip URLs targeting higher specs if they are served as dummy placeholders
      const currentUrl = sources[currentIndex];
      if (currentUrl.includes('maxresdefault') || currentUrl.includes('sddefault')) {
        setCurrentIndex(prev => prev + 1);
      }
    }
  };

  const handleError = () => {
    if (currentIndex < sources.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  const imageSrc = sources[currentIndex] || track.musicimg;

  return (
    <img
      src={imageSrc}
      alt={alt || track.musicname}
      onLoad={handleLoad}
      onError={handleError}
      className={className}
      referrerPolicy={referrerPolicy}
    />
  );
}
