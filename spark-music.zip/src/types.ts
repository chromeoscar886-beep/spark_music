export interface User {
  id: number;
  username: string;
  birthDate?: string;
}

export interface AuthResponse {
  status: string;
  message: string;
  token?: string;
  user?: User;
}

export interface Track {
  id: string;
  musicname: string;
  musicimg: string;
  description: string;
  musicviews: string;
  musiclink: string;
  artistname: string;
  country_code: string;
  facebook?: string;
  twitter?: string;
  instagram?: string;
  soundcloud?: string;
  spotify?: string;
  upload_on_server?: string;
  uploadDate: string;
  keyword_id?: string;
  musiclikes: string;
  channel_id?: string;
  channel_name: string;
}

export interface TrendingResponse {
  status: string;
  country: string;
  count: number;
  data: Track[];
}

export interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  recommended?: boolean;
  color: string;
}

export interface MostListenedArtist {
  artist_name: string;
  profile_image: string;
  views?: string;
  likes?: string;
  total_views?: number;
  total_likes?: number;
}

export interface MostListenedResponse {
  status: string;
  country_used: string;
  mode: string;
  count: number;
  data: MostListenedArtist[];
}

export function formatViews(views: string | number | undefined | null): string {
  if (views === null || views === undefined) return '0';
  const num = typeof views === 'number' ? views : parseInt(views.replace(/[^0-9.-]/g, '') || '0', 10);
  if (isNaN(num)) return typeof views === 'string' ? views : '0';
  
  if (num >= 1e9) {
    const formatted = num / 1e9;
    return (formatted % 1 === 0 ? formatted.toFixed(0) : formatted.toFixed(1)) + 'B';
  }
  if (num >= 1e6) {
    const formatted = num / 1e6;
    return (formatted % 1 === 0 ? formatted.toFixed(0) : formatted.toFixed(1)) + 'M';
  }
  if (num >= 1e3) {
    const formatted = num / 1e3;
    return (formatted % 1 === 0 ? formatted.toFixed(0) : formatted.toFixed(1)) + 'K';
  }
  return num.toString();
}

