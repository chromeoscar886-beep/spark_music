/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import PlayerPage from './pages/PlayerPage';
import ArtistPage from './pages/ArtistPage';
import Footer from './components/Footer';
import { PlayerProvider } from './contexts/PlayerContext';
import { AuthProvider } from './contexts/AuthContext';
import GlobalPlayerBar from './components/GlobalPlayerBar';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import Feed from './pages/Feed';
import AdminPage from './pages/AdminPage';
import Library from './pages/Library';

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <PlayerProvider>
          <div className="min-h-screen bg-black font-sans selection:bg-emerald-500/30 selection:text-emerald-500 flex flex-col">
            <Navbar />
            <main className="flex-grow pb-16 md:pb-24">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/track/:id" element={<PlayerPage />} />
                <Route path="/artist/:artistName" element={<ArtistPage />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/feed" element={<Feed />} />
                <Route path="/admin" element={<AdminPage />} />
                <Route path="/library" element={<Library />} />
              </Routes>
            </main>
            <Footer />
            <GlobalPlayerBar />
            
            {/* Progress Bar indicator (Top) */}
            <div className="fixed top-0 left-0 w-full h-[3px] z-[100] pointer-events-none">
              <div className="h-full bg-gradient-to-r from-emerald-500 via-green-400 to-yellow-300 shadow-[0_0_12px_rgba(16,185,129,0.8),_0_0_24px_rgba(234,179,8,0.5)] transition-all duration-300 w-0 relative" id="global-progress" />
            </div>
          </div>
        </PlayerProvider>
      </AuthProvider>
    </Router>
  );
}

