import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Play, Music, Users, ChevronLeft, Calendar } from 'lucide-react';
import { Track, formatViews } from '../types';
import { usePlayer } from '../contexts/PlayerContext';
import { musicApi } from '../services/api';
import MusicImage from '../components/MusicImage';

export default function ArtistPage() {
  const { artistName } = useParams();
  const navigate = useNavigate();
  const { setTrack, setAllTracks } = usePlayer();
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Dynamic SEO optimization for the artist page
  useEffect(() => {
    if (artistName) {
      document.title = `${artistName} - Discography, Profile & Stats | Spark Stream`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute('content', `Explore top hit releases, trending charts, listener count, and profile statistics for artist "${artistName}" on Spark Stream. Listen to their hottest music directly online.`);
      }
    }
  }, [artistName]);

  useEffect(() => {
    const fetchArtistTracks = async () => {
      if (!artistName) {
        setLoading(false);
        return;
      }
      
      setLoading(true);
      setError(null);
      
      try {
        const data = await musicApi.getArtistProfile(artistName);
        if (data.status === "success" && data.data) {
          setTracks(data.data);
        } else {
          setError(data.message || "Failed to find any data for this artist");
        }
      } catch (err) {
        console.error('Failed to load artist data:', err);
        setError("Could not connect to the music server. Please ensure the local API is running and accessible.");
      } finally {
        setLoading(false);
      }
    };

    fetchArtistTracks();
  }, [artistName]);

  const handleTrackClick = (track: Track) => {
    setTrack(track);
    setAllTracks(tracks); // Update queue context to this artist's tracks
    navigate(`/track/${track.id}`, { state: { track } });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  const placeholderImage = "https://images.unsplash.com/photo-1493225255756-d9584f8606e9?q=80&w=1000&auto=format&fit=crop";
  const artistImage = tracks.length > 0 ? tracks[0].musicimg : placeholderImage;

  return (
    <div className="min-h-screen bg-black text-white pb-24">
      {/* Header Section */}
      <div className="relative h-[250px] sm:h-[300px] md:h-[400px] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center scale-110 blur-2xl opacity-40 shadow-inner"
          style={{ backgroundImage: `url(${artistImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/60 to-black" />
        
        <div className="container mx-auto px-4 sm:px-6 h-full flex flex-col justify-end pb-8 sm:pb-12 relative z-10">
          <button 
            onClick={() => navigate(-1)}
            className="absolute top-4 sm:top-8 left-4 sm:left-6 p-2 sm:p-3 bg-black/40 hover:bg-black/60 backdrop-blur-md rounded-full transition-all border border-white/5"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          <div className="flex flex-col sm:flex-row items-center sm:items-end gap-4 sm:gap-6 text-center sm:text-left">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-20 h-20 sm:w-32 sm:h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-emerald-500/20 shadow-2xl shrink-0"
            >
              {tracks.length > 0 ? (
                <MusicImage track={tracks[0]} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <img src={placeholderImage} className="w-full h-full object-cover" />
              )}
            </motion.div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-center sm:justify-start gap-2 text-emerald-500 mb-2">
                <Users className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="text-[10px] sm:text-xs font-bold uppercase tracking-widest">Verified Artist</span>
              </div>
              <h1 className="text-3xl sm:text-5xl md:text-7xl font-black tracking-tighter mb-2 sm:mb-4 truncate">{artistName}</h1>
              <p className="text-zinc-400 max-w-xl text-xs sm:text-sm md:text-base line-clamp-2 md:line-clamp-3 overflow-hidden">
                Explore the latest releases and trending hits from {artistName}.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {error && (
          <div className="mb-8 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-500">
            <Music className="w-5 h-5 flex-shrink-0" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Track List */}
          <div className="lg:col-span-2 space-y-6 sm:space-y-8">
            <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-3">
              <Music className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-500" />
              Popular Releases
            </h2>

            <div className="space-y-2 sm:space-y-4">
              {tracks.length > 0 ? tracks.map((track, i) => (
                <motion.div 
                  key={track.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => handleTrackClick(track)}
                  className="group flex items-center gap-3 sm:gap-4 p-2 sm:p-3 rounded-xl hover:bg-zinc-900/50 transition-all cursor-pointer border border-transparent hover:border-white/5 active:scale-[0.98]"
                >
                  <div className="text-zinc-600 font-mono text-[10px] sm:text-sm w-4 sm:w-6 text-center group-hover:text-emerald-500 transition-colors">
                    {(i + 1).toString().padStart(2, '0')}
                  </div>
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded overflow-hidden flex-shrink-0">
                    <MusicImage track={track} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-bold text-xs sm:text-sm truncate uppercase group-hover:text-emerald-500 transition-colors">{track.musicname}</h4>
                    <p className="text-[10px] sm:text-xs text-zinc-500 truncate">{formatViews(track.musicviews)} plays</p>
                  </div>
                  <div className="hidden sm:flex items-center gap-2 text-zinc-500">
                    <Calendar className="w-3 h-3" />
                    <span className="text-[10px] font-mono">{track.uploadDate}</span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-black opacity-0 sm:group-hover:opacity-100 transition-opacity flex-shrink-0">
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  </div>
                </motion.div>
              )) : (
                <div className="text-center py-12 sm:py-20 bg-zinc-900/20 rounded-2xl border border-dashed border-white/5">
                   <Music className="w-10 h-10 sm:w-12 sm:h-12 text-zinc-800 mx-auto mb-4" />
                   <p className="text-zinc-500 text-sm">No tracks found for this artist.</p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar / Stats */}
          <div className="space-y-6 sm:space-y-8">
            <div className="bg-zinc-900/40 border border-white/5 p-4 sm:p-6 rounded-2xl">
              <h3 className="text-[10px] sm:text-xs font-bold text-zinc-500 uppercase tracking-widest mb-4 sm:mb-6">Artist Statistics</h3>
              <div className="space-y-4 sm:space-y-6">
                <StatItem label="Total Tracks" value={tracks.length.toString()} />
                <StatItem label="Total Plays" value={formatViews(tracks.reduce((acc, t) => acc + parseInt(t.musicviews || '0'), 0))} />
                <StatItem label="Active Since" value={tracks.length > 0 && tracks[tracks.length - 1].uploadDate ? tracks[tracks.length - 1].uploadDate.split('-')[0] : 'N/A'} />
              </div>
            </div>

            <div className="p-1 px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
              <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-wider text-center">
                Artist profile verified by Spark Music
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-end border-b border-white/5 pb-4">
      <span className="text-zinc-500 text-sm">{label}</span>
      <span className="text-xl font-bold font-mono text-emerald-400">{value}</span>
    </div>
  );
}
