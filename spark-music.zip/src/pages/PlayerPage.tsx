import { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, 
  Heart, Repeat, Share2, MessageCircle, Send, MoreHorizontal, Trash2,
  ListMusic, Lock, User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Track, formatViews } from '../types';
import { usePlayer } from '../contexts/PlayerContext';
import { useAuth } from '../contexts/AuthContext';
import { musicApi } from '../services/api';
import MusicImage, { getYouTubeVideoId } from '../components/MusicImage';

const COLORS = [
  '#10b981', // Emerald
  '#6366f1', // Indigo
  '#f43f5e', // Rose
  '#0ea5e9', // Sky
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#8b5cf6', // Violet
];

function parseHexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

function interpolateColors(colors: string[], ratio: number): string {
  if (!colors || colors.length === 0) return '#10b981';
  if (colors.length === 1) return colors[0];
  if (ratio <= 0) return colors[0];
  if (ratio >= 1) return colors[colors.length - 1];

  const scaledRatio = ratio * (colors.length - 1);
  const index = Math.floor(scaledRatio);
  const segmentRatio = scaledRatio - index;

  const c1 = parseHexToRgb(colors[index]) || { r: 16, g: 185, b: 129 };
  const c2 = parseHexToRgb(colors[index + 1]) || { r: 99, g: 102, b: 241 };

  const r = Math.round(c1.r + (c2.r - c1.r) * segmentRatio);
  const g = Math.round(c1.g + (c2.g - c1.g) * segmentRatio);
  const b = Math.round(c1.b + (c2.b - c1.b) * segmentRatio);

  const toHexStr = (val: number) => {
    const s = Math.max(0, Math.min(255, val)).toString(16);
    return s.length === 1 ? '0' + s : s;
  };
  return `#${toHexStr(r)}${toHexStr(g)}${toHexStr(b)}`;
}

function ProceduralVisualizer({ playing, colors }: { playing: boolean; colors: string[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const barsRef = useRef<{ h: number; t: number; v: number }[]>(
    new Array(60).fill(0).map(() => ({ h: 4, t: 4, v: 0 }))
  );
  const frameRef = useRef(0);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const width = canvas.width;
      const height = canvas.height;
      const barCount = barsRef.current.length;
      const spacing = 3;
      const barWidth = (width - (barCount - 1) * spacing) / barCount;

      frameRef.current++;

      for (let i = 0; i < barCount; i++) {
        const bar = barsRef.current[i];
        if (playing) {
          const base = Math.sin(frameRef.current * 0.05 + i * 0.1) * 10 + 20;
          const jitter = Math.random() < 0.1 ? Math.random() * 50 : 0;
          const energy = i < barCount * 0.2 ? 1.5 : (i < barCount * 0.6 ? 1.0 : 0.6);
          bar.t = (base + jitter) * energy + 5;
          const force = (bar.t - bar.h) * 0.2;
          bar.v = bar.v * 0.8 + force;
          bar.h += bar.v;
        } else {
          bar.h += (4 - bar.h) * 0.1;
          bar.v = 0;
        }
        const x = i * (barWidth + spacing);
        const barHeight = Math.max(4, bar.h);
        const y = height - barHeight;

        const ratio = barCount > 1 ? i / (barCount - 1) : 0;
        const barColor = interpolateColors(colors, ratio);

        const gradient = ctx.createLinearGradient(x, y, x, height);
        gradient.addColorStop(0, barColor);
        gradient.addColorStop(1, barColor + '22');
        ctx.fillStyle = gradient;
        ctx.shadowBlur = playing ? 12 : 0;
        ctx.shadowColor = barColor;
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(x, y, barWidth, barHeight, 2);
        else ctx.fillRect(x, y, barWidth, barHeight);
        ctx.fill();
      }
      animationId = requestAnimationFrame(render);
    };
    render();
    return () => cancelAnimationFrame(animationId);
  }, [playing, colors]);

  return <canvas ref={canvasRef} width={800} height={120} className="w-full h-full pointer-events-none" />;
}

export default function PlayerPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state } = useLocation();
  const { 
    currentTrack, setTrack, playing, togglePlay, volume, setVolume, 
    muted, setMuted, played, duration, seekTo, setAllTracks, 
    allTracks, navigateToTrack, isLiked, likesCount, toggleLike,
    activeColor, activeColors
  } = usePlayer();
  const { isAuthenticated, user, token } = useAuth();

  const [trackLoading, setTrackLoading] = useState(true);
  const vizColor = activeColor;

  const [comments, setComments] = useState<any[]>([]);
  const [visibleComments, setVisibleComments] = useState(20);
  const [newComment, setNewComment] = useState('');
  const [isDeleting, setIsDeleting] = useState<number | null>(null);

  const [isInPlaylist, setIsInPlaylist] = useState(false);
  const [addingToPlaylist, setAddingToPlaylist] = useState(false);
  const [playlistParticles, setPlaylistParticles] = useState<Array<{
    id: number;
    color: string;
    size: number;
    angle: number;
    distance: number;
  }>>([]);

  // Sync playlist status from local storage
  useEffect(() => {
    if (currentTrack?.id) {
      const username = user?.username || 'root';
      const key = `spark_playlist_ids_${username}`;
      const playlistIds = JSON.parse(localStorage.getItem(key) || '[]');
      setIsInPlaylist(playlistIds.includes(currentTrack.id));
    }
  }, [currentTrack?.id, user?.username]);

  const triggerPlaylistParticles = (type: 'add' | 'remove') => {
    const count = 28;
    const newParticles = [];
    const colors = type === 'add' 
      ? ['#10b981', '#34d399', '#059669', '#6ee7b7', '#a7f3d0'] 
      : ['#f43f5e', '#fb7185', '#e11d48', '#fda4af', '#fecdd3'];
      
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 25 + Math.random() * 65;
      const size = 2.5 + Math.random() * 4.5;
      const color = colors[Math.floor(Math.random() * colors.length)];
      
      newParticles.push({
        id: Math.random() + Date.now() + i,
        color,
        size,
        angle,
        distance
      });
    }
    
    setPlaylistParticles(newParticles);
    
    // Clear particles after animation completes
    setTimeout(() => {
      setPlaylistParticles([]);
    }, 850);
  };

  const handleAddToPlaylist = async () => {
    if (!currentTrack?.id) return;
    
    const username = user?.username || 'root';
    const key = `spark_playlist_ids_${username}`;
    setAddingToPlaylist(true);

    if (isInPlaylist) {
      // DELETE track from playlist
      try {
        await musicApi.addToPlaylist(currentTrack.id, username, 'delete');
        setIsInPlaylist(false);
        const playlistIds = JSON.parse(localStorage.getItem(key) || '[]');
        const updatedIds = playlistIds.filter((id: string) => id !== currentTrack.id);
        localStorage.setItem(key, JSON.stringify(updatedIds));
        triggerPlaylistParticles('remove');
      } catch (err) {
        console.error('Playlist delete error:', err);
        setIsInPlaylist(false);
        const playlistIds = JSON.parse(localStorage.getItem(key) || '[]');
        const updatedIds = playlistIds.filter((id: string) => id !== currentTrack.id);
        localStorage.setItem(key, JSON.stringify(updatedIds));
        triggerPlaylistParticles('remove');
      } finally {
        setAddingToPlaylist(false);
      }
    } else {
      // ADD track to playlist
      try {
        const res = await musicApi.addToPlaylist(currentTrack.id, username);
        if (res.status === 'success' || (res.status === 'error' && res.message && res.message.toLowerCase().includes('already exists'))) {
          setIsInPlaylist(true);
          const playlistIds = JSON.parse(localStorage.getItem(key) || '[]');
          if (!playlistIds.includes(currentTrack.id)) {
            playlistIds.push(currentTrack.id);
            localStorage.setItem(key, JSON.stringify(playlistIds));
          }
          triggerPlaylistParticles('add');
        } else {
          setIsInPlaylist(true);
          const playlistIds = JSON.parse(localStorage.getItem(key) || '[]');
          if (!playlistIds.includes(currentTrack.id)) {
            playlistIds.push(currentTrack.id);
            localStorage.setItem(key, JSON.stringify(playlistIds));
          }
          triggerPlaylistParticles('add');
        }
      } catch (err) {
        console.error('Playlist add error:', err);
        setIsInPlaylist(true);
        const playlistIds = JSON.parse(localStorage.getItem(key) || '[]');
        if (!playlistIds.includes(currentTrack.id)) {
          playlistIds.push(currentTrack.id);
          localStorage.setItem(key, JSON.stringify(playlistIds));
        }
        triggerPlaylistParticles('add');
      } finally {
        setAddingToPlaylist(false);
      }
    }
  };

  // Reset visible comments when track changes
  useEffect(() => {
    setVisibleComments(20);
  }, [currentTrack?.id]);

  // Dynamic SEO optimization for tracks
  useEffect(() => {
    if (currentTrack) {
      document.title = `${currentTrack.musicname} - Listen on Spark Stream`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute('content', `Listen online to "${currentTrack.musicname}" by ${currentTrack.artistname || currentTrack.channel_name || 'Artist'} on Spark Stream. View real-time feedback, interactive ratings, comment timeline, and explore similar music trends.`);
      }
    }
  }, [currentTrack]);

  // Sync track state
  useEffect(() => {
    if (state?.track) {
      setTrack(state.track);
      setTrackLoading(false);
    } else if (id && allTracks.length > 0) {
      const found = allTracks.find(t => t.id === id);
      if (found) {
        setTrack(found);
        setTrackLoading(false);
      }
    }
  }, [id, state, allTracks]);

  // Fetch comments
  useEffect(() => {
    const fetchComments = async () => {
      if (!currentTrack?.id) return;
      try {
        const data = await musicApi.getComments(currentTrack.id, user?.username);
        if (data && data.comments && Array.isArray(data.comments)) {
          setComments(data.comments.map((c: any) => ({
            id: c.id || Math.random() + Date.now(),
            user: c.username || 'Anonymous',
            text: c.comment || '',
            time: c.date_add || c.created_at || 'Recent',
            avatar: `https://ui-avatars.com/api/?name=${c.username || 'User'}&background=random`
          })));
        } else {
          setComments([]);
        }
      } catch (err) {
        console.error('Failed to fetch comments:', err);
      }
    };
    fetchComments();
  }, [currentTrack?.id, user?.username]);

  const handleSendComment = async () => {
    if (!newComment || !isAuthenticated || !currentTrack?.id || !user?.username) return;

    try {
      const data = await musicApi.addComment(currentTrack.id, user.username, newComment);

      if (data && (data.status === 'success' || data.comments)) {
        // Re-fetch comments
        const reloadData = await musicApi.getComments(currentTrack.id, user.username);
        if (reloadData && reloadData.comments && Array.isArray(reloadData.comments)) {
          setComments(reloadData.comments.map((c: any) => ({
            id: c.id || Math.random() + Date.now(),
            user: c.username || 'Anonymous',
            text: c.comment || '',
            time: c.date_add || c.created_at || 'Recent',
            avatar: `https://ui-avatars.com/api/?name=${c.username || 'User'}&background=random`
          })));
        }
        setNewComment('');
      } else {
        alert(data.message || 'Failed to post comment');
      }
    } catch (err) {
      console.error('Comment error:', err);
      alert('Failed to send comment. Please try again.');
    }
  };

  const handleDeleteComment = async () => {
    if (!currentTrack?.id || !user?.username) return;

    try {
      const data = await musicApi.deleteComment(currentTrack.id, user.username);

      if (data && (data.status === 'success' || data.comments)) {
        const reloadData = await musicApi.getComments(currentTrack.id, user.username);
        setComments(reloadData && reloadData.comments && Array.isArray(reloadData.comments) ? reloadData.comments.map((c: any) => ({
          id: c.id || Math.random() + Date.now(),
          user: c.username || 'Anonymous',
          text: c.comment || '',
          time: c.date_add || c.created_at || 'Recent',
          avatar: `https://ui-avatars.com/api/?name=${c.username || 'User'}&background=random`
        })) : []);
      } else {
        alert(data.message || 'Failed to delete comment');
      }
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setIsDeleting(null);
    }
  };

  // Load trends if empty
  useEffect(() => {
    const loadTrends = async () => {
      try {
        const json = await musicApi.getMainTrends();
        if (json.status === "success" && json.data) {
          setAllTracks(json.data);
          if (!currentTrack && id) {
            const found = json.data.find((t: Track) => t.id === id);
            if (found) setTrack(found);
            else navigate('/');
          }
        }
      } catch (err) {
        console.error('Failed to load data:', err);
      } finally {
        if (!state?.track) setTrackLoading(false);
      }
    };
    if (allTracks.length === 0) loadTrends();
    else setTrackLoading(false);
  }, []);

  // Save history
  useEffect(() => {
    if (currentTrack?.id) {
      localStorage.setItem('spark_last_track_id', currentTrack.id);
      const history = JSON.parse(localStorage.getItem('spark_history') || '[]');
      const newHistory = [currentTrack, ...history.filter((t: Track) => t.id !== currentTrack.id)].slice(0, 14);
      localStorage.setItem('spark_history', JSON.stringify(newHistory));
    }
  }, [currentTrack]);

  if (trackLoading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
       <div className="w-12 h-12 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin" />
    </div>
  );

  if (!currentTrack) return null;

  const formatTime = (seconds: number) => {
    const date = new Date(seconds * 1000);
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds().toString().padStart(2, '0');
    return `${mm}:${ss}`;
  };

  return (
    <div className="min-h-screen bg-black text-white pb-24">
      {/* Header / Hero Section */}
      <div className="relative h-auto min-h-[420px] md:h-[450px] pt-4 sm:pt-8 md:pt-0 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center scale-110 blur-3xl opacity-30"
          style={{ backgroundImage: `url(${currentTrack.musicimg})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black" />

        <div className="container mx-auto px-4 md:px-6 h-full flex items-center relative z-10 pt-20 pb-8 md:py-10">
          <div className="flex flex-col md:flex-row items-center md:items-end gap-6 md:gap-10 w-full text-center md:text-left">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-48 h-48 sm:w-64 sm:h-64 md:w-[340px] md:h-[340px] aspect-square rounded-lg shadow-2xl shadow-emerald-500/10 overflow-hidden shrink-0 border border-emerald-500/10"
            >
              <MusicImage track={currentTrack} alt={currentTrack.musicname} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            </motion.div>

            <div className="flex flex-col justify-center flex-1 w-full max-w-full overflow-hidden">
              <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6 mb-4">
                <motion.button 
                  whileHover={{ scale: 1.15 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={togglePlay}
                  className="w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center bg-white text-black shadow-2xl transition-all hover:bg-neutral-100 shrink-0"
                >
                  {playing ? <Pause className="w-6 h-6 md:w-8 md:h-8 fill-current" /> : <Play className="w-6 h-6 md:w-8 md:h-8 fill-current ml-1" />}
                </motion.button>
                <div className="min-w-0 flex-1">
                   <h1 className="text-xl sm:text-2xl md:text-5xl font-extrabold tracking-tight mb-2 line-clamp-2 md:line-clamp-none leading-tight">{currentTrack.musicname}</h1>
                   <p 
                    onClick={() => navigate(`/artist/${encodeURIComponent(currentTrack.artistname || currentTrack.channel_name)}`)}
                    className="text-base md:text-xl font-medium transition-colors cursor-pointer hover:opacity-80" 
                    style={{ color: vizColor }}
                   >
                    {currentTrack.artistname || currentTrack.channel_name}
                   </p>
                </div>
              </div>
              <div className="h-12 md:h-24 mb-4 md:mb-8 opacity-80 w-full overflow-hidden">
                 <ProceduralVisualizer playing={playing} colors={activeColors} />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12 mt-8 md:mt-12">
        <div className="lg:col-span-2 space-y-12">
          <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-4 py-4 border-y border-white/5 min-w-0">
             <div className="flex items-center gap-6">
                <button 
                  onClick={toggleLike}
                  className={`flex items-center gap-2 transition-all active:scale-95 ${isLiked ? 'text-red-500' : 'text-zinc-400'}`} 
                  style={{ color: isLiked ? '#ef4444' : vizColor }}
                >
                  <motion.div
                    animate={isLiked ? { scale: [1, 1.3, 1] } : {}}
                    transition={{ duration: 0.3 }}
                  >
                    <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                  </motion.div>
                  <span className="text-sm font-bold">{likesCount}</span>
                </button>
                <button className="flex items-center gap-2 text-zinc-400 hover:opacity-80 transition-opacity">
                  <Share2 className="w-5 h-5" />
                  <span className="text-sm font-bold">Share</span>
                </button>
                <div className="relative flex items-center justify-center">
                  <button 
                    onClick={handleAddToPlaylist}
                    disabled={addingToPlaylist}
                    className={`flex items-center justify-center p-1.5 transition-all relative group shrink-0 hover:bg-white/5 rounded-full ${
                      isInPlaylist 
                        ? 'text-emerald-500 hover:text-emerald-400 font-bold scale-105' 
                        : 'text-zinc-400 hover:text-white'
                    }`}
                    style={isInPlaylist ? { color: '#10b981' } : {}}
                    title={isInPlaylist ? "Added to Playlist!" : "Add to Playlist"}
                  >
                    <ListMusic className={`w-5 h-5 ${isInPlaylist ? 'stroke-[2.5px] scale-110' : ''}`} />
                    <span className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-zinc-950 text-white text-[10px] font-bold px-2 py-1 rounded shadow-xl border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap uppercase tracking-wider z-50">
                      {isInPlaylist ? "Added to Playlist!" : "Add to Playlist"}
                    </span>
                  </button>

                  {/* Absolute particle container centered with button */}
                  <div className="absolute pointer-events-none inset-0 flex items-center justify-center z-50 overflow-visible">
                    <AnimatePresence>
                      {playlistParticles.map(p => {
                        const targetX = Math.cos(p.angle) * p.distance;
                        const targetY = Math.sin(p.angle) * p.distance;

                        return (
                          <motion.div
                            key={p.id}
                            initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
                            animate={{ 
                              x: targetX, 
                              y: targetY, 
                              scale: 0, 
                              opacity: 0,
                              rotate: Math.random() * 360
                            }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.8, ease: "easeOut" }}
                            className="absolute rounded-full"
                            style={{
                              width: p.size,
                              height: p.size,
                              backgroundColor: p.color,
                              boxShadow: `0 0 10px ${p.color}, 0 0 4px ${p.color}`
                            }}
                          />
                        );
                      })}
                    </AnimatePresence>
                  </div>
                </div>
             </div>
             <div className="flex items-center gap-1.5 text-zinc-400 bg-white/5 py-1 px-2.5 rounded-md text-[10px] xs:text-xs font-mono uppercase tracking-widest shrink-0 min-w-0 max-w-full overflow-hidden">
               <Play className="w-3 h-3 text-emerald-500 shrink-0 fill-current" />
               <span className="truncate whitespace-nowrap font-bold">{formatViews(currentTrack.musicviews)} Plays</span>
             </div>
          </div>

          <div className="flex gap-4 sm:gap-6 items-start min-w-0">
             <div 
              className="w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center shrink-0 border transition-colors"
              style={{ backgroundColor: `${vizColor}33`, borderColor: `${vizColor}33` }}
             >
               <MusicImage track={currentTrack} className="w-full h-full rounded-full object-cover" />
             </div>
             <div className="flex-1 min-w-0">
                <h3 
                  onClick={() => navigate(`/artist/${encodeURIComponent(currentTrack.artistname || currentTrack.channel_name)}`)}
                  className="font-bold mb-1 cursor-pointer transition-colors truncate" 
                  style={{ color: vizColor }}
                >
                  {currentTrack.artistname || currentTrack.channel_name}
                </h3>
                 <p className="text-zinc-500 text-[13px] leading-relaxed mb-6 break-words w-full max-w-xl md:max-w-2xl">
                   {currentTrack.description || "The artist hasn't provided a description for this track yet."}
                 </p>
             </div>
          </div>

          <div className="space-y-8">
            <h3 className="text-lg font-bold flex items-center gap-2">
              <MessageCircle className="w-5 h-5" style={{ color: vizColor }} />
              {comments.length} Comments
            </h3>

            <div className="flex flex-col gap-4 bg-zinc-900/50 p-4 rounded-xl border border-white/5 relative overflow-hidden group">
               {!isAuthenticated && (
                 <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center text-center p-4">
                   <Lock className="w-8 h-8 text-emerald-500 mb-2 opacity-50" />
                   <p className="text-sm font-bold text-white mb-3">Join the conversation</p>
                   <div className="flex items-center gap-2">
                     <button 
                      onClick={() => navigate('/login')}
                      className="px-4 py-1.5 bg-emerald-500 text-black text-[10px] font-black rounded-lg uppercase tracking-wider hover:bg-emerald-400 transition-all"
                     >
                       Sign In
                     </button>
                     <span className="text-[10px] text-zinc-500 font-bold uppercase">or</span>
                     <button 
                      onClick={() => navigate('/register')}
                      className="px-4 py-1.5 bg-white/10 text-white text-[10px] font-black rounded-lg uppercase tracking-wider hover:bg-white/20 transition-all"
                     >
                       Sign Up
                     </button>
                   </div>
                 </div>
               )}
               
               <div className="flex gap-4 items-center">
                 <div className="w-8 h-8 rounded-full bg-zinc-800 shrink-0 flex items-center justify-center">
                    {isAuthenticated ? (
                      <span className="text-xs font-bold text-emerald-500">{user?.username[0].toUpperCase()}</span>
                    ) : (
                      <User className="w-4 h-4 text-zinc-600" />
                    )}
                 </div>
                 <input 
                  type="text" 
                  disabled={!isAuthenticated}
                  placeholder={isAuthenticated ? "Write a comment..." : "Login to join the community"} 
                  className="flex-1 bg-transparent border-none outline-none text-sm placeholder:text-zinc-600 disabled:cursor-not-allowed"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSendComment();
                  }}
                 />
                 <button 
                  onClick={handleSendComment}
                  disabled={!isAuthenticated || !newComment}
                  className="p-2 transition-all rounded-md disabled:opacity-30" 
                  style={{ color: vizColor }}
                 >
                  <Send className="w-4 h-4" />
                 </button>
               </div>
            </div>

            <div className="space-y-6">
              <AnimatePresence>
                {isDeleting !== null && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
                  >
                    <motion.div 
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="bg-zinc-900 border border-white/10 p-6 rounded-3xl max-w-sm w-full shadow-2xl"
                    >
                      <h3 className="text-xl font-black uppercase tracking-tight text-white mb-2">Delete Comment?</h3>
                      <p className="text-zinc-400 text-sm mb-6">Are you sure you want to remove your comment? This action cannot be undone.</p>
                      <div className="flex gap-3">
                        <button 
                          onClick={() => setIsDeleting(null)}
                          className="flex-1 py-3 px-4 bg-white/5 hover:bg-white/10 rounded-xl text-white text-xs font-bold transition-colors"
                        >
                          CANCEL
                        </button>
                        <button 
                          onClick={handleDeleteComment}
                          className="flex-1 py-3 px-4 bg-red-500 hover:bg-red-400 rounded-xl text-white text-xs font-bold transition-colors"
                        >
                          DELETE
                        </button>
                      </div>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>

              {comments.slice(0, visibleComments).map((comment, i) => (
                <div key={`${comment.id}-${i}`} className="flex gap-4 group min-w-0">
                  <img src={comment.avatar} className="w-10 h-10 rounded-full bg-zinc-800 shrink-0" referrerPolicy="no-referrer" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-zinc-400">{comment.user}</span>
                        <span className="text-[10px] font-mono opacity-60" style={{ color: vizColor }}>at {comment.time}</span>
                      </div>
                      {isAuthenticated && user?.username === comment.user && (
                        <button 
                          onClick={() => setIsDeleting(comment.id)}
                          className="opacity-0 group-hover:opacity-100 p-1 text-zinc-600 hover:text-red-500 transition-all"
                          title="Delete Comment"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <p className="text-sm text-zinc-300 break-words w-full">{comment.text}</p>
                  </div>
                </div>
              ))}

              {comments.length > visibleComments && (
                <button 
                  onClick={() => setVisibleComments(prev => prev + 10)}
                  className="w-full py-4 text-xs font-bold text-zinc-500 hover:text-white transition-colors border-t border-white/5 uppercase tracking-widest"
                >
                  Load More Comments ({comments.length - visibleComments} remaining)
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-10">
           <div className="bg-zinc-900/30 rounded-xl p-6 border border-white/5">
              <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-6">Track Info</h4>
              <div className="space-y-4">
                 <InfoItem label="Release Date" value={currentTrack.uploadDate} />
                 <InfoItem label="Country" value={currentTrack.country_code} />
                 <InfoItem label="Artist" value={currentTrack.artistname || currentTrack.channel_name} />
                 <InfoItem label="Genre" value={currentTrack.keyword_id || 'Electronic'} />
              </div>
           </div>

           <div className="space-y-6">
             <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">You might also like</h4>
             {allTracks.filter(t => t.id !== currentTrack.id).slice(0, 5).map((t, i) => (
               <div key={`${t.id}-${i}`} onClick={() => { setTrack(t); navigate(`/track/${t.id}`, { state: { track: t } }); }} className="flex gap-3 group cursor-pointer">
                 <div className="w-12 h-12 bg-zinc-800 rounded overflow-hidden shrink-0">
                    <MusicImage track={t} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                 </div>
                 <div className="flex-1 overflow-hidden">
                    <div className="text-sm font-bold truncate transition-colors" style={{ color: vizColor }}>{t.musicname}</div>
                    <div className="text-xs text-zinc-500 truncate">{t.artistname}</div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 w-full z-[100] bg-black/95 backdrop-blur-xl border-t px-2 xs:px-4 md:px-6 py-2 md:py-3 flex items-center justify-between gap-1.5 xs:gap-3 md:gap-4 select-none" style={{ borderColor: `${vizColor}33` }}>
        <div className="flex items-center gap-1.5 xs:gap-2.5 md:gap-4 w-auto max-w-[32%] xs:max-w-[35%] md:w-1/4 md:min-w-[200px] overflow-hidden min-w-0 shrink-0">
          <MusicImage track={currentTrack} className="w-7 h-7 xs:w-9 xs:h-9 md:w-12 md:h-12 rounded object-cover flex-shrink-0" />
          <div className="overflow-hidden min-w-0">
            <div className="text-[10px] xs:text-[11px] md:text-sm font-bold truncate">{currentTrack.musicname}</div>
            <div 
              onClick={() => navigate(`/artist/${encodeURIComponent(currentTrack.artistname || currentTrack.channel_name)}`)}
              className="text-[9px] xs:text-[10px] md:text-xs text-zinc-500 truncate hover:text-white transition-colors cursor-pointer"
            >
              {currentTrack.artistname || currentTrack.channel_name}
            </div>
          </div>
          <button 
            onClick={toggleLike}
            className={`transition-all active:scale-90 flex-shrink-0 ${isLiked ? 'text-red-500' : 'text-zinc-500'}`} 
            style={{ color: isLiked ? '#ef4444' : vizColor }}
          >
            <Heart className={`w-3 h-3 xs:w-3.5 xs:h-3.5 md:w-4 md:h-4 ${isLiked ? 'fill-current' : ''}`} />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center gap-0.5 md:gap-1 min-w-0">
          <div className="flex items-center gap-1.5 xs:gap-4 md:gap-6 mb-1">
            <button className="text-zinc-400 hover:text-white transition-colors hidden md:block" title="Repeat"><Repeat className="w-4 h-4" /></button>
            <button onClick={() => navigateToTrack(-1)} className="text-zinc-200 hover:text-white active:scale-90 transition-all"><SkipBack className="w-3.5 h-3.5 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current" /></button>
            <button onClick={togglePlay} className="w-7.5 h-7.5 xs:w-9 xs:h-9 md:w-10 md:h-10 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg shrink-0">
              {playing ? <Pause className="w-3 h-3 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current" /> : <Play className="w-3 h-3 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current ml-0.5" />}
            </button>
            <button onClick={() => navigateToTrack(1)} className="text-zinc-200 hover:text-white active:scale-90 transition-all"><SkipForward className="w-3.5 h-3.5 xs:w-4 xs:h-4 md:w-5 md:h-5 fill-current" /></button>
            <button className="text-zinc-400 hover:text-white transition-colors hidden md:block"><MoreHorizontal className="w-4 h-4" /></button>
          </div>
          
          <div className="w-full flex items-center gap-2 md:gap-3 py-1">
            <span className="text-[10px] font-mono text-zinc-500 w-7 md:w-10 text-right">{formatTime(played * duration)}</span>
            <div className="flex-1 h-4 md:h-8 flex items-center relative group">
              <input 
                type="range" min={0} max={0.999999} step="any"
                value={played}
                onChange={(e) => seekTo(parseFloat(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                style={{ touchAction: 'none' }}
              />
              {/* Visual Bar */}
              <div className="w-full h-1.5 md:h-1 bg-zinc-800 rounded-full relative overflow-hidden">
                <div className="absolute left-0 top-0 h-full rounded-full" style={{ width: `${played * 100}%`, backgroundColor: vizColor }} />
              </div>
              {/* Handle */}
              <div className="absolute top-1/2 -translate-y-1/2 w-4 h-4 md:w-3 md:h-3 bg-white rounded-full shadow-2xl md:opacity-0 md:group-hover:opacity-100 transition-opacity z-10 pointer-events-none" style={{ left: `${played * 100}%`, marginLeft: '-8px' }} />
            </div>
            <span className="text-[10px] font-mono text-zinc-500 w-7 md:w-10">{formatTime(duration)}</span>
          </div>
        </div>

        <div className="items-center gap-4 w-1/4 justify-end hidden md:flex">
          <div className="flex items-center gap-2 group">
            <button onClick={() => setMuted(!muted)} className="text-zinc-400 hover:text-white transition-colors">
              {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
            <div className="w-20 h-1 bg-zinc-800 rounded-full relative">
               <input 
                type="range" min={0} max={1} step="any"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
               />
               <div className="absolute left-0 top-0 h-full rounded-full" style={{ width: `${volume * 100}%`, backgroundColor: vizColor }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center text-xs">
      <span className="text-zinc-500 font-medium">{label}</span>
      <span className="text-zinc-300 font-mono">{value}</span>
    </div>
  );
}
