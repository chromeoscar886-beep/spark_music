import { useEffect } from 'react';
import Hero from '../components/Hero';
import TrendingTracks from '../components/TrendingTracks';
import Pricing from '../components/Pricing';
import RecentlyPlayed from '../components/RecentlyPlayed';

export default function Home() {
  useEffect(() => {
    document.title = "Spark Stream - Global Music Charts & Smart Player";
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', "Spark Stream is a next-generation music hub to discover trending streaming charts, enjoy localized feeds, look up artists, and listen to high-quality music seamlessly.");
    }
  }, []);

  return (
    <>
      <Hero />
      <RecentlyPlayed />
      <TrendingTracks />
      <Pricing />
    </>
  );
}
