import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Globe, Play, Music, Eye, ChevronLeft, ChevronRight } from 'lucide-react';
import { usePlayer } from '../contexts/PlayerContext';
import { Track, formatViews } from '../types';
import { musicApi } from '../services/api';
import MusicImage from '../components/MusicImage';
import MostListenedProfiles from '../components/MostListenedProfiles';

const COUNTRIES = [
    { code: "GLOBAL", name: "Global", flag: "🌎" },
    { code: "US", name: "USA", flag: "🇺🇸" },
    { code: "CN", name: "China", flag: "🇨🇳" },
    { code: "IN", name: "India", flag: "🇮🇳" },
    { code: "JP", name: "Japan", flag: "🇯🇵" },
    { code: "DE", name: "Germany", flag: "🇩🇪" },
    { code: "GB", name: "UK", flag: "🇬🇧" },
    { code: "FR", name: "France", flag: "🇫🇷" },
    { code: "BR", name: "Brazil", flag: "🇧🇷" },
    { code: "IT", name: "Italy", flag: "🇮🇹" },
    { code: "CA", name: "Canada", flag: "🇨🇦" },
    { code: "RU", name: "Russia", flag: "🇷🇺" },
    { code: "KR", name: "S. Korea", flag: "🇰🇷" },
    { code: "ES", name: "Spain", flag: "🇪🇸" },
    { code: "AU", name: "Australia", flag: "🇦🇺" },
    { code: "MX", name: "Mexico", flag: "🇲🇽" },
    { code: "ID", name: "Indonesia", flag: "🇮🇩" },
    { code: "TR", name: "Turkey", flag: "🇹🇷" },
    { code: "SA", name: "Saudi Arabia", flag: "🇸🇦" },
    { code: "AE", name: "UAE", flag: "🇦🇪" },
    { code: "EG", name: "Egypt", flag: "🇪🇬" },
    { code: "ZA", name: "S. Africa", flag: "🇿🇦" },
    { code: "NL", name: "Netherlands", flag: "🇳🇱" },
    { code: "SE", name: "Sweden", flag: "🇸🇪" },
    { code: "CH", name: "Switzerland", flag: "🇨🇭" },
    { code: "PL", name: "Poland", flag: "🇵🇱" },
    { code: "BE", name: "Belgium", flag: "🇧🇪" },
    { code: "AR", name: "Argentina", flag: "🇦🇷" },
    { code: "TH", name: "Thailand", flag: "🇹🇭" },
    { code: "MY", name: "Malaysia", flag: "🇲🇾" },
    { code: "PH", name: "Philippines", flag: "🇵🇭" },
    { code: "AT", name: "Austria", flag: "🇦🇹" },
    { code: "BO", name: "Bolivia", flag: "🇧🇴" },
    { code: "CL", name: "Chile", flag: "🇨🇱" },
    { code: "CO", name: "Colombia", flag: "🇨🇴" },
    { code: "CR", name: "Costa Rica", flag: "🇨🇷" },
    { code: "CZ", name: "Czech Rep.", flag: "🇨🇿" },
    { code: "DK", name: "Denmark", flag: "🇩🇰" },
    { code: "EC", name: "Ecuador", flag: "🇪🇨" },
    { code: "SV", name: "El Salvador", flag: "🇸🇻" },
    { code: "EE", name: "Estonia", flag: "🇪🇪" },
    { code: "FI", name: "Finland", flag: "🇫🇮" },
    { code: "GT", name: "Guatemala", flag: "🇬🇹" },
    { code: "HN", name: "Honduras", flag: "🇭🇳" },
    { code: "HK", name: "Hong Kong", flag: "🇭🇰" },
    { code: "HU", name: "Hungary", flag: "🇭🇺" },
    { code: "IS", name: "Iceland", flag: "🇮🇸" },
    { code: "IE", name: "Ireland", flag: "🇮🇪" },
    { code: "IL", name: "Israel", flag: "🇮🇱" },
    { code: "KE", name: "Kenya", flag: "🇰🇪" },
    { code: "LU", name: "Luxembourg", flag: "🇱🇺" },
    { code: "NZ", name: "New Zealand", flag: "🇳🇿" },
    { code: "NI", name: "Nicaragua", flag: "🇳🇮" },
    { code: "NG", name: "Nigeria", flag: "🇳🇬" },
    { code: "NO", name: "Norway", flag: "🇳🇴" },
    { code: "PA", name: "Panama", flag: "🇵🇦" },
    { code: "PY", name: "Paraguay", flag: "🇵🇾" },
    { code: "PE", name: "Peru", flag: "🇵🇪" },
    { code: "PT", name: "Portugal", flag: "🇵🇹" },
    { code: "RO", name: "Romania", flag: "🇷🇴" },
    { code: "RS", name: "Serbia", flag: "🇷🇸" },
    { code: "SG", name: "Singapore", flag: "🇸🇬" },
    { code: "TZ", name: "Tanzania", flag: "🇹🇿" },
    { code: "UA", name: "Ukraine", flag: "🇺🇦" },
    { code: "VN", name: "Vietnam", flag: "🇻🇳" },
    { code: "ZW", name: "Zimbabwe", flag: "🇿🇼" },
    { code: "UY", name: "Uruguay", flag: "🇺🇾" },
    { code: "UG", name: "Uganda", flag: "🇺🇬" }
];

const TRACKS_PER_PAGE = 15;

export default function Feed() {
  const navigate = useNavigate();
  const [selectedCountry, setSelectedCountry] = useState(COUNTRIES[0]);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const { currentTrack, setTrack, setAllTracks } = usePlayer();

  // Monetization framework state loads
  const [adsSettings, setAdsSettings] = useState<{
    adSenseEnabled: boolean;
    adSensePubId: string;
    adSenseSlotId: string;
    adSenseAuto: boolean;
    propellerEnabled: boolean;
    propellerZoneId: string;
    propellerFormat: string;
    propellerLink: string;
    infolinksEnabled: boolean;
    infolinksPid: string;
    infolinksWsid: string;
    popadsEnabled: boolean;
    popadsId: string;
    popadsMinBid: string;
    placement: string;
  }>({
    adSenseEnabled: false,
    adSensePubId: '',
    adSenseSlotId: '',
    adSenseAuto: false,
    propellerEnabled: false,
    propellerZoneId: '',
    propellerFormat: '',
    propellerLink: '',
    infolinksEnabled: false,
    infolinksPid: '',
    infolinksWsid: '',
    popadsEnabled: false,
    popadsId: '',
    popadsMinBid: '',
    placement: 'top'
  });

  useEffect(() => {
    setAdsSettings({
      adSenseEnabled: localStorage.getItem('spark_adsense_enabled') === 'true',
      adSensePubId: localStorage.getItem('spark_adsense_pub_id') || 'pub-8742918837107755',
      adSenseSlotId: localStorage.getItem('spark_adsense_slot_id') || '4928371029',
      adSenseAuto: localStorage.getItem('spark_adsense_auto_ads') !== 'false',
      propellerEnabled: localStorage.getItem('spark_propeller_enabled') === 'true',
      propellerZoneId: localStorage.getItem('spark_propeller_zone_id') || '7482910',
      propellerFormat: localStorage.getItem('spark_propeller_format') || 'popunder',
      propellerLink: localStorage.getItem('spark_propeller_direct_link') || 'https://propeller_direct_link.com/link?zone=7482910',
      infolinksEnabled: localStorage.getItem('spark_infolinks_enabled') === 'true',
      infolinksPid: localStorage.getItem('spark_infolinks_pid') || '364893',
      infolinksWsid: localStorage.getItem('spark_infolinks_wsid') || '0',
      popadsEnabled: localStorage.getItem('spark_popads_enabled') === 'true',
      popadsId: localStorage.getItem('spark_popads_id') || '5829104',
      popadsMinBid: localStorage.getItem('spark_popads_min_bid') || '0.001',
      placement: localStorage.getItem('spark_ads_placement') || 'top'
    });
  }, []);

  // Dynamic SEO optimization for the feed page
  useEffect(() => {
    if (currentTrack) {
      document.title = `▶ Playing: ${currentTrack.musicname} - Spark Stream`;
    } else {
      document.title = `${selectedCountry.name} Music Feed & Top Trends - Spark Stream`;
    }

    // Pro-tier SEO Metas updates
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', currentTrack
        ? `Currently listening to "${currentTrack.musicname}" by ${currentTrack.artistname || currentTrack.channel_name || 'Artist'}. Discover region-specific hot music feeds from Saudi Arabia, United States, Global charts, and more on Spark Stream.`
        : `Explore and listen to the top trending music in ${selectedCountry.name} region page. Read stats, see view counts, and stream the hottest hits with Spark Stream's premium Spotify-style feed.`
      );
    }
  }, [currentTrack, selectedCountry]);

  useEffect(() => {
    const fetchTracks = async () => {
      setLoading(true);
      try {
        const data = await musicApi.getTracks(selectedCountry.code === 'GLOBAL' ? undefined : selectedCountry.code);
        
        if (data.status === 'success' && data.data) {
          const fetchedTracks = data.data;
          setTracks(fetchedTracks);
          setAllTracks(fetchedTracks);
        } else {
          setTracks([]);
        }
      } catch (err) {
        console.error('Failed to fetch tracks:', err);
        setTracks([]);
      } finally {
        setLoading(false);
        setCurrentPage(1); // Reset to first page on country change
      }
    };

    fetchTracks();
  }, [selectedCountry]);

  // Pagination logic
  const totalPages = Math.ceil(tracks.length / TRACKS_PER_PAGE);
  const startIndex = (currentPage - 1) * TRACKS_PER_PAGE;
  const paginatedTracks = tracks.slice(startIndex, startIndex + TRACKS_PER_PAGE);

  const handlePlay = (track: Track, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setTrack(track);
    navigate(`/track/${track.id}`, { state: { track } });
  };

  return (
    <div className="min-h-screen bg-black text-white pb-32">

      {/* Top AdSense Banner Slot */}
      {adsSettings.adSenseEnabled && (adsSettings.placement === 'top' || adsSettings.placement === 'both') && (
        <div className="max-w-7xl mx-auto px-6 pt-6 mb-[-12px]">
          <div className="border border-amber-500/10 bg-amber-500/[0.02] p-4 text-center rounded-2xl relative overflow-hidden ring-1 ring-amber-500/5 hover:border-amber-500/20 transition-all">
            <span className="absolute right-3 top-3 text-[8px] font-mono tracking-widest bg-amber-500/10 text-amber-500 font-bold px-1.5 py-0.5 rounded leading-none">GOOGLE ADSENSE (SPONSORED)</span>
            <div className="text-[10px] font-black text-amber-500/95 uppercase tracking-widest mb-1 font-mono">PARTNER PROMOTIONAL BANNER</div>
            <p className="text-xs text-zinc-350 max-w-2xl mx-auto font-sans leading-relaxed">
              🔥 Ready to elevate your tracks onto international stages? Connect your Spotify artist account to Spark Creator panel for free distribution tools!
            </p>
            <span className="block text-[8px] text-zinc-650 font-mono mt-1 px-1 py-0.5 select-all">ca-pub-{adsSettings.adSensePubId} // slot-{adsSettings.adSenseSlotId}</span>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Most Listened Profiles Section */}
        <MostListenedProfiles country={selectedCountry.code} />

        {/* Propeller Popunder / Smartlink interactive gateway */}
        {adsSettings.propellerEnabled && adsSettings.propellerFormat === 'popunder' && (
          <div className="mb-6 flex items-center justify-between bg-zinc-950 border border-purple-500/15 p-4 rounded-2xl">
            <div className="space-y-0.5 pr-4">
              <span className="inline-block text-[8px] font-mono tracking-widest bg-purple-500/10 text-purple-400 font-bold px-1.5 py-0.5 rounded uppercase mb-1">Propeller Smartlink</span>
              <h4 className="text-xs font-black text-zinc-300 uppercase">Interactive Sponsor Popunder</h4>
              <p className="text-[10px] text-zinc-500 leading-normal">Our algorithms dynamically monetize outbound traffic streams. Support Spark servers by checking optional partner links!</p>
            </div>
            <a 
              href={adsSettings.propellerLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-4 py-2 bg-purple-500/10 hover:bg-purple-500 hover:text-white border border-purple-500/20 text-purple-400 font-bold font-mono text-[10px] uppercase rounded-xl transition-all cursor-pointer whitespace-nowrap"
            >
              Check Smartlink Ads ↗
            </a>
          </div>
        )}

        {/* Propeller Banner Native Zone */}
        {adsSettings.propellerEnabled && adsSettings.propellerFormat === 'banner' && (adsSettings.placement === 'feed' || adsSettings.placement === 'both') && (
          <div className="mb-6 border border-purple-500/20 bg-purple-500/[0.02] p-4 text-center rounded-2xl relative overflow-hidden ring-1 ring-purple-500/5 hover:border-purple-500/30 transition-all">
            <span className="absolute right-3 top-3 text-[8px] font-mono tracking-widest bg-purple-500/10 text-purple-400 font-bold px-1.5 py-0.5 rounded leading-none">PROPELLER ADS (NATIVE ZONE)</span>
            <div className="text-[10px] font-black text-purple-400 uppercase tracking-widest mb-1 font-mono">TRACK LEVEL MONETIZATION UNIT</div>
            <p className="text-xs text-zinc-350 max-w-2xl mx-auto font-sans">
              🎁 Complete standard listener quests to claim up to <span className="text-purple-400 font-bold">100 premium streaming tokens</span> now! Connect zone entry points below.
            </p>
            <span className="text-[8px] font-mono text-zinc-650 select-all block mt-1">zone-{adsSettings.propellerZoneId}</span>
          </div>
        )}



        {loading ? (
          <div className="flex flex-col gap-3">
            {[...Array(12)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 p-2 sm:p-3 bg-zinc-900/20 border border-white/5 rounded-2xl animate-pulse">
                <div className="w-10 h-6 bg-zinc-900/60 rounded-full" />
                <div className="w-12 h-12 bg-zinc-900/60 rounded-xl" />
                <div className="flex-grow space-y-2">
                  <div className="h-4 bg-zinc-900/60 rounded-full w-1/3" />
                  <div className="h-3 bg-zinc-900/60 rounded-full w-1/4" />
                </div>
                <div className="w-20 h-4 bg-zinc-900/60 rounded-full hidden sm:block" />
                <div className="w-16 h-6 bg-zinc-900/60 rounded-full shrink-0" />
              </div>
            ))}
          </div>
        ) : paginatedTracks.length > 0 ? (
          <>
            <div className="space-y-2.5">
              {/* Spotify-style Header Row */}
              <div className="hidden sm:grid grid-cols-[50px_1.5fr_1fr_120px_100px] items-center gap-4 px-4 py-3 text-zinc-500 font-extrabold text-[11px] uppercase tracking-wider border-b border-white/5 mb-3 select-none">
                <div className="text-center">#</div>
                <div>Title</div>
                <div>Artist</div>
                <div className="flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span>Views</span>
                </div>
                <div className="text-right">Region</div>
              </div>

              {/* Special live row for currently running track */}
              {currentTrack && (
                <div 
                  onClick={(e) => handlePlay(currentTrack, e)}
                  className="group flex sm:grid sm:grid-cols-[50px_1.5fr_1fr_120px_100px] items-center gap-4 p-2 sm:p-3 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent border border-emerald-500/30 hover:border-emerald-500/50 cursor-pointer shadow-lg shadow-emerald-500/5 relative mb-4 transition-all duration-300"
                >
                  {/* Glowing pulse aura */}
                  <div className="absolute inset-0 bg-emerald-500/[0.02] animate-pulse pointer-events-none rounded-2xl" />
                  
                  {/* Animated micro equalizer bars representing live running track */}
                  <div className="w-10 sm:w-auto text-center flex items-center justify-center shrink-0">
                    <div className="flex gap-[2px] items-end justify-center h-4 w-5">
                      {[1, 2, 3].map((val) => (
                        <motion.span
                          key={val}
                          className="w-[3px] bg-emerald-400 rounded-full"
                          animate={{ height: ["4px", "14px", "4px"] }}
                          transition={{
                            repeat: Infinity,
                            duration: 0.5 + val * 0.15,
                            ease: "easeInOut"
                          }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Title and Cover art */}
                  <div className="flex items-center gap-3.5 min-w-0 flex-1 relative z-10">
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-zinc-900 border border-emerald-500/30 shrink-0 relative shadow-[0_0_12px_rgba(16,185,129,0.2)]">
                      <MusicImage 
                        track={currentTrack} 
                        alt={currentTrack.musicname} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="min-w-0 pr-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[8px] font-black uppercase tracking-wider bg-emerald-500 text-black px-1 rounded-sm leading-none py-0.5">NOW RUNNING</span>
                      </div>
                      <h3 className="font-extrabold text-sm sm:text-base text-emerald-400 group-hover:text-emerald-300 transition-colors duration-200 truncate leading-snug mt-1.5">
                        {currentTrack.musicname}
                      </h3>
                      {/* Mobile display of artist underneath title */}
                      <p className="sm:hidden text-xs font-medium text-zinc-400 truncate mt-0.5 max-w-[180px]">
                        {currentTrack.channel_name || currentTrack.artistname}
                      </p>
                    </div>
                  </div>

                  {/* Artist/Channel (Desktop only) */}
                  <div className="hidden sm:block min-w-0 relative z-10">
                    <p className="text-sm font-semibold text-zinc-200 truncate group-hover:text-zinc-100 transition-colors duration-200">
                      {currentTrack.channel_name || currentTrack.artistname}
                    </p>
                  </div>

                  {/* Views Count */}
                  <div className="hidden sm:flex items-center gap-1.5 min-w-0 text-emerald-300 font-mono text-xs relative z-10 font-bold">
                    <span>{formatViews(currentTrack.musicviews)}</span>
                  </div>

                  {/* Country Code & mobile content */}
                  <div className="ml-auto sm:ml-0 flex items-center gap-3 shrink-0 justify-end relative z-10">
                    <span className="text-[10px] font-black font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-md uppercase tracking-wide">
                      {currentTrack.country_code || 'GLOBAL'}
                    </span>
                  </div>
                </div>
              )}

              {paginatedTracks.map((track, idx) => {
                const globalIndex = (currentPage - 1) * TRACKS_PER_PAGE + idx + 1;
                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ 
                      duration: 0.4, 
                      ease: [0.16, 1, 0.3, 1],
                      delay: (idx % 10) * 0.02
                    }}
                    key={`${track.id}-${idx}`}
                    onClick={(e) => handlePlay(track, e)}
                    className="group flex sm:grid sm:grid-cols-[50px_1.5fr_1fr_120px_100px] items-center gap-4 p-2 sm:p-3 rounded-2xl hover:bg-zinc-900/50 border border-transparent hover:border-white/5 cursor-pointer transition-all duration-300 relative"
                  >
                    {/* Position / Play Button trigger */}
                    <div className="w-10 sm:w-auto text-center flex items-center justify-center shrink-0">
                      <span className="text-xs font-black font-mono text-zinc-500 group-hover:opacity-0 transition-all duration-200">
                        {globalIndex}
                      </span>
                      <div className="absolute opacity-0 group-hover:opacity-100 transition-all duration-200 text-emerald-400">
                        <Play className="w-4 h-4 fill-emerald-400" />
                      </div>
                    </div>

                    {/* Title and Cover art */}
                    <div className="flex items-center gap-3.5 min-w-0 flex-1">
                      <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl overflow-hidden bg-zinc-900 border border-white/10 shrink-0 relative group-hover:border-emerald-500/20 transition-all duration-300">
                        <MusicImage 
                          track={track} 
                          alt={track.musicname} 
                          className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="min-w-0 pr-1">
                        <h3 className="font-bold text-sm sm:text-base text-zinc-100 group-hover:text-emerald-400 transition-colors duration-200 truncate leading-snug">
                          {track.musicname}
                        </h3>
                        {/* Mobile display of artist underneath title */}
                        <p className="sm:hidden text-xs font-medium text-zinc-500 truncate mt-0.5 max-w-[180px]">
                          {track.channel_name || track.artistname}
                        </p>
                      </div>
                    </div>

                    {/* Artist/Channel (Desktop only) */}
                    <div className="hidden sm:block min-w-0">
                      <p className="text-sm font-semibold text-zinc-400 truncate group-hover:text-zinc-200 transition-colors duration-200">
                        {track.channel_name || track.artistname}
                      </p>
                    </div>

                    {/* Views Count */}
                    <div className="hidden sm:flex items-center gap-1.5 min-w-0 text-zinc-400 font-mono text-xs">
                      <span>{formatViews(track.musicviews)}</span>
                    </div>

                    {/* Country Code & mobile content */}
                    <div className="ml-auto sm:ml-0 flex items-center gap-3 shrink-0 justify-end">
                      {/* Mobile display of views */}
                      <span className="sm:hidden text-xs font-mono text-zinc-500">
                        {formatViews(track.musicviews)}
                      </span>
                      
                      <span className="text-[10px] font-black font-mono text-emerald-500/80 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md uppercase tracking-wide">
                        {track.country_code || selectedCountry.code}
                      </span>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="mt-24 flex items-center justify-center gap-6">
                <button 
                  disabled={currentPage === 1}
                  onClick={() => {
                    setCurrentPage(p => p - 1);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-14 h-14 rounded-3xl bg-zinc-900/50 backdrop-blur-md border border-white/10 flex items-center justify-center hover:border-emerald-500 disabled:opacity-20 disabled:hover:border-white/10 transition-all text-zinc-400 hover:text-emerald-500 shadow-xl"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                
                <div className="flex items-center gap-3">
                  {[...Array(totalPages)].map((_, i) => {
                    const pageNum = i + 1;
                    if (totalPages <= 7 || pageNum === 1 || pageNum === totalPages || (pageNum >= currentPage - 1 && pageNum <= currentPage + 1)) {
                      return (
                        <button
                          key={pageNum}
                          onClick={() => {
                            setCurrentPage(pageNum);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className={`w-14 h-14 rounded-3xl text-sm font-black transition-all border ${
                            currentPage === pageNum 
                              ? 'bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/20' 
                              : 'bg-zinc-900/50 border-white/10 text-zinc-500 hover:border-emerald-500/50 hover:text-white'
                          }`}
                        >
                          {pageNum}
                        </button>
                      );
                    }
                    if (pageNum === currentPage - 2 || pageNum === currentPage + 2) {
                      return <span key={pageNum} className="text-zinc-600 font-bold px-2">···</span>;
                    }
                    return null;
                  })}
                </div>

                <button 
                  disabled={currentPage === totalPages}
                  onClick={() => {
                    setCurrentPage(p => p + 1);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-14 h-14 rounded-3xl bg-zinc-900/50 backdrop-blur-md border border-white/10 flex items-center justify-center hover:border-emerald-500 disabled:opacity-20 disabled:hover:border-white/10 transition-all text-zinc-400 hover:text-emerald-500 shadow-xl"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>
            )}
          </>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="py-48 text-center"
          >
             <div className="w-24 h-24 bg-zinc-900/50 rounded-full flex items-center justify-center mx-auto mb-8 border border-white/5">
                <Music className="w-10 h-10 text-zinc-700" />
             </div>
             <h2 className="text-3xl font-black uppercase tracking-tight text-white mb-3 italic">Nothing to <span className="text-emerald-500">Find</span></h2>
             <p className="text-zinc-500 text-xs font-black uppercase tracking-[0.2em]">No tracks currently trending in this region.</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
