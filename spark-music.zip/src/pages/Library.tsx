import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { usePlayer } from '../contexts/PlayerContext';
import { musicApi, getApiBaseUrl } from '../services/api';
import { Track } from '../types';
import { 
  Heart, 
  HeartOff,
  ListMusic, 
  Play, 
  Trash2, 
  Music, 
  Compass, 
  Calendar, 
  Loader2, 
  Sparkles,
  ArrowRight,
  Disc
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import MusicImage from '../components/MusicImage';

interface ApiLikedTrack {
  music_id: string;
  date_add: string;
  likes_count: number | string;
}

interface ApiPlaylistTrack {
  track_id: string;
  token_playlist: string;
}

export default function Library() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { currentTrack, setTrack, setAllTracks, playing, togglePlay } = usePlayer();

  const [activeTab, setActiveTab] = useState<'liked' | 'playlist'>('liked');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Raw data from process.php
  const [rawLiked, setRawLiked] = useState<ApiLikedTrack[]>([]);
  const [rawPlaylist, setRawPlaylist] = useState<ApiPlaylistTrack[]>([]);

  // Catalog tracks for resolution
  const [catalogMap, setCatalogMap] = useState<Record<string, Track>>({});

  // Resolved lists
  const [resolvedLikedTracks, setResolvedLikedTracks] = useState<Track[]>([]);
  const [resolvedPlaylistTracks, setResolvedPlaylistTracks] = useState<Track[]>([]);

  // Page titles and description SEO setup
  useEffect(() => {
    document.title = "Your Personal Music Library - Spark Stream";
  }, []);

  const fetchLibraryData = async () => {
    if (!user?.username) return;
    setLoading(true);
    setError(null);

    try {
      // 1. Fetch user's custom liked and playlist track rosters
      const url = `${getApiBaseUrl()}/process.php?playlist_and_liked_tracks&username=${encodeURIComponent(user.username)}`;
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`HTTP Error ${res.status}: Failed to reach the registration process gateway.`);
      }
      const data = await res.json();

      let likedList: ApiLikedTrack[] = [];
      let playlistList: ApiPlaylistTrack[] = [];

      if (data && data.status === 'success') {
        // Parse list formats robustly (handles arrays and object list responses)
        if (data.liked_tracks) {
          likedList = Array.isArray(data.liked_tracks) 
            ? data.liked_tracks 
            : Object.values(data.liked_tracks);
        }
        if (data.playlist_tracks) {
          playlistList = Array.isArray(data.playlist_tracks) 
            ? data.playlist_tracks 
            : Object.values(data.playlist_tracks);
        }
      }

      setRawLiked(likedList);
      setRawPlaylist(playlistList);

      // 2. Fetch the catalog records across general country-codes to maximize resolution coverage
      const tracksMap: Record<string, Track> = {};
      
      try {
        // Fetch global tracks
        const globalData = await musicApi.getTracks();
        if (globalData && globalData.status === 'success' && Array.isArray(globalData.data)) {
          globalData.data.forEach((track: Track) => {
            if (track && track.id) {
              tracksMap[String(track.id)] = track;
            }
          });
        }
      } catch (err) {
        console.warn('Could not fetch global catalog for resolution:', err);
      }

      try {
        // Also fetch trending tracks to supplement mapping database
        const trendsData = await musicApi.getMainTrends();
        if (trendsData && trendsData.status === 'success' && Array.isArray(trendsData.data)) {
          trendsData.data.forEach((track: Track) => {
            if (track && track.id) {
              tracksMap[String(track.id)] = track;
            }
          });
        }
      } catch (err) {
        console.warn('Could not fetch trends catalog for resolution:', err);
      }

      setCatalogMap(tracksMap);

      // 3. Map liked tracks
      const resolvedLiked = likedList.map((item) => {
        const matched = tracksMap[String(item.music_id)];
        if (matched) {
          return { ...matched };
        }
        // Robust fallback construction representing unregistered records elegantly
        return {
          id: String(item.music_id),
          musicname: `Track #${item.music_id}`,
          artistname: 'Unknown Artist',
          musicimg: '',
          description: 'Custom registered library track entry.',
          musicviews: '0',
          musiclink: '',
          country_code: 'US',
          uploadDate: item.date_add || 'N/A',
          musiclikes: String(item.likes_count || '1'),
          channel_name: 'Database Archives'
        } as Track;
      });

      // 4. Map playlist tracks
      const resolvedPlaylist = playlistList.map((item) => {
        const matched = tracksMap[String(item.track_id)];
        if (matched) {
          return { ...matched };
        }
        // Fallback for missing music records
        return {
          id: String(item.track_id),
          musicname: `Playlist Track #${item.track_id}`,
          artistname: 'Archived Artist',
          musicimg: '',
          description: `Custom playlist track with token identity code: ${item.token_playlist || 'notoken'}.`,
          musicviews: '0',
          musiclink: '',
          country_code: 'US',
          uploadDate: 'N/A',
          musiclikes: '1',
          channel_name: 'Custom Playlists'
        } as Track;
      });

      setResolvedLikedTracks(resolvedLiked);
      setResolvedPlaylistTracks(resolvedPlaylist);

    } catch (err: any) {
      console.error('Library Loading Error:', err);
      setError(err.message || 'Failed to sync your personalized music settings list.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchLibraryData();
    } else {
      setLoading(false);
    }
  }, [isAuthenticated, user]);

  const handlePlayAll = (tracksToLoad: Track[], startIndex = 0) => {
    if (tracksToLoad.length === 0) return;
    const initialTrack = tracksToLoad[startIndex];
    setTrack(initialTrack);
    setAllTracks(tracksToLoad);
    
    // Smoothly route to player screen or launch immediate inline player
    navigate(`/track/${initialTrack.id}`, { state: { track: initialTrack } });
  };

  const handleUnlikeTrack = async (e: React.MouseEvent, trackId: string) => {
    e.stopPropagation();
    if (!user?.username) return;

    try {
      const response = await musicApi.toggleLike(trackId, user.username);
      if (response && response.status === 'success') {
        // Instantly reload and sync state directly with the process.php db
        fetchLibraryData();
      } else {
        // Fallback filter out on UI directly first
        setResolvedLikedTracks(prev => prev.filter(t => t.id !== trackId));
      }
    } catch (error) {
      console.error('Error toggling like removal in library:', error);
      // Clean reload anyway
      fetchLibraryData();
    }
  };

  const handleRemoveFromPlaylist = async (e: React.MouseEvent, trackId: string) => {
    e.stopPropagation();
    if (!user?.username) return;

    try {
      // Pass "0" or toggle deletion for that specific playlist item
      const response = await musicApi.addToPlaylist(trackId, user.username, "0");
      if (response && response.status === 'success') {
        fetchLibraryData();
      } else {
        setResolvedPlaylistTracks(prev => prev.filter(t => t.id !== trackId));
      }
    } catch (error) {
      console.error('Error removing from playlist in library:', error);
      fetchLibraryData();
    }
  };

  const currentList = activeTab === 'liked' ? resolvedLikedTracks : resolvedPlaylistTracks;

  if (!isAuthenticated) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-black min-h-[75vh]">
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-zinc-950 border border-white/5 rounded-3xl p-8 text-center space-y-6 shadow-2xl relative overflow-hidden"
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 bg-emerald-500/10 rounded-full blur-[50px] pointer-events-none" />
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-2 border border-emerald-500/20">
            <Music className="w-8 h-8 animate-pulse" />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-black text-white uppercase tracking-tight">Access Locked</h2>
            <p className="text-sm text-zinc-400">
              Please sign in to your profile to view your personal library folder containing loved tracks, interactive statistics, and curated custom playlists.
            </p>
          </div>
          <button 
            onClick={() => navigate('/login')}
            className="w-full py-3 px-6 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-black uppercase tracking-widest rounded-xl transition-all active:scale-95 shadow-lg shadow-emerald-500/15 cursor-pointer"
          >
            Access My Account
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white relative">
      {/* Background ambient lighting gradients */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-emerald-950/20 rounded-full blur-[160px] pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-[400px] h-[400px] bg-purple-950/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-10 relative z-10 space-y-8">
        
        {/* Breadcrumb / Top Title block */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 pb-6 border-b border-white/5">
          <div className="space-y-2">
            <h1 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight flex items-center gap-3">
              Your Library
            </h1>
            <p className="text-zinc-500 text-sm max-w-xl">
              Hello, <strong className="text-emerald-400 font-bold">{user?.username}</strong>. Discover individual liked scores and manage offline playlist tracks stored securely on the host database.
            </p>
          </div>

          {currentList.length > 0 && (
            <button
              onClick={() => handlePlayAll(currentList)}
              className="px-6 py-3 rounded-2xl text-xs font-bold uppercase tracking-wider bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/15 flex items-center gap-2.5 transition-all active:scale-95 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-black" />
              <span>Play Stack</span>
            </button>
          )}
        </div>

        {/* Dashboard Grid Header */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-zinc-950/60 border border-white/5 rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-red-500/15 text-red-500 rounded-xl flex items-center justify-center border border-red-500/10">
              <Heart className="w-5 h-5 fill-red-500" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Loved Tracks</div>
              <div className="text-2xl font-black text-white">{resolvedLikedTracks.length}</div>
            </div>
          </div>

          <div className="bg-zinc-950/60 border border-white/5 rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-500/15 text-indigo-400 rounded-xl flex items-center justify-center border border-indigo-500/10">
              <ListMusic className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider">Playlist Tracks</div>
              <div className="text-2xl font-black text-white">{resolvedPlaylistTracks.length}</div>
            </div>
          </div>
        </div>

        {/* Tab Controls Selector */}
        <div className="flex border-b border-white/5 gap-2 select-none">
          <button
            onClick={() => setActiveTab('liked')}
            className={`px-5 py-3 text-xs uppercase font-extrabold tracking-widest relative transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'liked' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <Heart className={`w-3.5 h-3.5 ${activeTab === 'liked' ? 'text-red-500 fill-red-500' : ''}`} />
            <span>Loved Tracks</span>
            {activeTab === 'liked' && (
              <motion.div 
                layoutId="activeTabIndicator" 
                className="absolute bottom-0 left-0 right-0 h-[2px] bg-emerald-400" 
              />
            )}
          </button>

          <button
            onClick={() => setActiveTab('playlist')}
            className={`px-5 py-3 text-xs uppercase font-extrabold tracking-widest relative transition-all cursor-pointer flex items-center gap-2 ${
              activeTab === 'playlist' ? 'text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            <ListMusic className="w-3.5 h-3.5" />
            <span>My Playlists</span>
            {activeTab === 'playlist' && (
              <motion.div 
                layoutId="activeTabIndicator" 
                className="absolute bottom-0 left-0 right-0 h-[2px] bg-emerald-400" 
              />
            )}
          </button>
        </div>

        {/* Main Content Area */}
        {loading ? (
          <div className="py-24 flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-10 h-10 text-emerald-500 animate-spin" />
            <div className="text-xs font-mono uppercase tracking-widest text-zinc-500 animate-pulse">
              Retrieving database relations...
            </div>
          </div>
        ) : error ? (
          <div className="py-16 text-center bg-zinc-950/40 border border-white/5 rounded-3xl p-8 max-w-xl mx-auto space-y-4">
            <p className="text-xs text-red-400 font-mono italic">Error: {error}</p>
            <button
              onClick={fetchLibraryData}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-black uppercase tracking-widest rounded-xl transition-all"
            >
              Try Synchronizing Again
            </button>
          </div>
        ) : currentList.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="py-20 text-center bg-zinc-950/25 border border-dashed border-white/10 rounded-3xl p-8 space-y-5"
          >
            <div className="w-12 h-12 bg-zinc-900/80 rounded-full flex items-center justify-center mx-auto text-zinc-650">
              {activeTab === 'liked' ? <Heart className="w-6 h-6" /> : <ListMusic className="w-6 h-6" />}
            </div>
            <div className="space-y-1.5">
              <h3 className="text-md font-bold text-zinc-300 uppercase tracking-tight">Your Stack is Empty</h3>
              <p className="text-xs text-zinc-500 max-w-md mx-auto">
                {activeTab === 'liked' 
                  ? "You haven't hit the heart icon on any tracks yet! Browse our trending stream page or search for items to grow your catalog."
                  : "No playlist logs loaded. Save your preferred music to your playlist directories to access them instantly."}
              </p>
            </div>
            <button
              onClick={() => navigate('/')}
              className="px-5 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-emerald-400 text-[10px] font-black uppercase tracking-widest rounded-xl border border-white/5 inline-flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <span>Explore Stream Catalog</span>
              <Compass className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-white/5 bg-zinc-950/40 backdrop-blur-md">
            <table className="w-full text-left border-collapse font-mono text-xs">
              <thead>
                <tr className="border-b border-white/5 text-[9px] uppercase tracking-wider text-zinc-500 font-extrabold select-none">
                  <th className="py-4 px-4 text-center w-12">#</th>
                  <th className="py-4 px-4">Title</th>
                  <th className="py-4 px-4">Publisher / Artist</th>
                  <th className="py-4 px-4 text-center">Country</th>
                  <th className="py-4 px-4 text-right w-36">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-zinc-300">
                {currentList.map((track, index) => {
                  const isNowPlaying = currentTrack?.id === track.id;
                  
                  return (
                    <tr 
                      key={`${track.id}-${index}`}
                      onClick={() => handlePlayAll(currentList, index)}
                      className={`hover:bg-white/[0.02] group transition-all duration-150 cursor-pointer ${
                        isNowPlaying ? 'bg-emerald-500/[0.04]' : ''
                      }`}
                    >
                      {/* Play Action / Index */}
                      <td className="py-4 px-4 text-center text-zinc-500 font-bold">
                        <div className="flex items-center justify-center">
                          {isNowPlaying && playing ? (
                            <div className="flex gap-[2px] items-end justify-center h-3 w-4">
                              {[1, 2, 3].map((val) => (
                                <span
                                  key={val}
                                  className="w-[2px] bg-emerald-400 rounded-full animate-pulse"
                                  style={{ animationDuration: `${0.4 + val * 0.1}s` }}
                                />
                              ))}
                            </div>
                          ) : (
                            <span className="group-hover:hidden">{index + 1}</span>
                          )}
                          <Play className="w-3.5 h-3.5 fill-emerald-500 text-emerald-500 hidden group-hover:block mx-auto" />
                        </div>
                      </td>

                      {/* Title & Cover */}
                      <td className="py-4 px-4 font-sans text-sm">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg overflow-hidden bg-zinc-900 border border-white/10 shrink-0 relative">
                            <MusicImage 
                              track={track} 
                              alt={track.musicname}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div className="min-w-0">
                            <div className={`font-extrabold text-sm truncate uppercase tracking-tight ${
                              isNowPlaying ? 'text-emerald-400' : 'text-white'
                            }`}>
                              {track.musicname}
                            </div>
                            {track.channel_name && (
                              <div className="text-zinc-500 text-xs truncate max-w-[150px] sm:max-w-xs mt-0.5">
                                {track.description || "Database Registered Hit"}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Display Artist / Publisher */}
                      <td className="py-4 px-4 font-sans font-medium text-zinc-400">
                        {track.artistname || track.channel_name || 'Anonymous Artist'}
                      </td>

                      {/* Country Code */}
                      <td className="py-4 px-4 text-center select-none font-sans font-black">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-zinc-900 text-zinc-400 border border-white/5 uppercase">
                          {track.country_code || 'US'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-4 text-right">
                        <div className="flex justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                          {activeTab === 'liked' ? (
                            <button
                              onClick={(e) => handleUnlikeTrack(e, track.id)}
                              className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/10 hover:border-red-500/30 transition-colors cursor-pointer"
                              title="Unlike this track"
                            >
                              <HeartOff className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={(e) => handleRemoveFromPlaylist(e, track.id)}
                              className="p-1.5 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/10 hover:border-indigo-500/30 transition-colors cursor-pointer"
                              title="Delete from playlist"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
