import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User as UserIcon, Lock, Calendar, Camera, Save, 
  Heart, Music, ChevronRight, Loader2, CheckCircle, AlertCircle 
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Track } from '../types';
import { usePlayer } from '../contexts/PlayerContext';
import { musicApi } from '../services/api';
import MusicImage from '../components/MusicImage';

export default function Profile() {
  const { user, login } = useAuth();
  const { allTracks, setTrack } = usePlayer();

  useEffect(() => {
    document.title = user ? `${user.username}'s Profile - Spark Stream` : "User Profile - Spark Stream";
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', "Manage your Spark Stream account, view favorite tracks, and modify settings inside your user hub.");
    }
  }, [user]);
  
  const [username, setUsername] = useState(user?.username || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [birthDate, setBirthDate] = useState(user?.birthDate || '');
  const [avatar, setAvatar] = useState(`https://ui-avatars.com/api/?name=${user?.username}&background=随机`);
  
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [favorites, setFavorites] = useState<Track[]>([]);

  useEffect(() => {
    // Simulate fetching user's favorite tracks
    // In a real app, you would fetch this from your API
    const favs = allTracks.slice(0, 3); // Just as example
    setFavorites(favs);
  }, [allTracks]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage({ type: '', text: '' });

    if (password && password !== confirmPassword) {
      setMessage({ type: 'error', text: 'Passwords do not match' });
      setIsLoading(false);
      return;
    }

    try {
      const data = await musicApi.updateUser({ 
        id: user?.id,
        username, 
        password: password || undefined,
        birthDate 
      });

      if (data.status === 'success') {
        setMessage({ type: 'success', text: 'Profile updated successfully!' });
        if (user) {
          login({ ...user, username, birthDate }, localStorage.getItem('token') || '');
        }
      } else {
        setMessage({ type: 'error', text: data.message || 'Update failed.' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Connection to server failed. Profile saved locally for now.' });
      // Temporary local update for demo if server fails
      if (user) {
        login({ ...user, username, birthDate }, localStorage.getItem('token') || '');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black pt-24 pb-32 px-4 lg:px-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Profile Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-3xl p-8 text-center"
          >
            <div className="relative w-32 h-32 mx-auto mb-6 group">
              <img 
                src={avatar} 
                alt="Profile" 
                className="w-full h-full rounded-2xl object-cover border-4 border-emerald-500/20 shadow-2xl shadow-emerald-500/10"
                referrerPolicy="no-referrer"
              />
              <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-emerald-500 text-black rounded-xl flex items-center justify-center hover:bg-emerald-400 transition-colors shadow-lg active:scale-95 group-hover:rotate-12 transition-transform">
                <Camera className="w-5 h-5" />
              </button>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tighter uppercase mb-1">{user?.username}</h2>
            <p className="text-zinc-500 text-sm font-medium mb-6">Music Enthusiast</p>
            
            <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white/5">
              <div className="text-center">
                <p className="text-emerald-500 font-black text-xl">{favorites.length}</p>
                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Favorites</p>
              </div>
              <div className="text-center">
                <p className="text-white font-black text-xl">12</p>
                <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Playlists</p>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-3xl p-6"
          >
            <h3 className="flex items-center gap-2 text-white font-black uppercase text-sm mb-6 tracking-widest">
              <Heart className="w-4 h-4 text-rose-500" />
              Recent Favorites
            </h3>
            <div className="space-y-4">
              {favorites.map((track, i) => (
                <div 
                  key={`${track.id}-${i}`} 
                  onClick={() => setTrack(track)}
                  className="flex items-center gap-4 group cursor-pointer hover:bg-white/5 p-2 rounded-xl transition-colors"
                >
                  <MusicImage track={track} className="w-12 h-12 rounded-lg" alt="" referrerPolicy="no-referrer" />
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-bold text-sm truncate">{track.musicname}</p>
                    <p className="text-zinc-500 text-xs truncate">{track.artistname}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-emerald-500 transition-colors" />
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Edit Profile Form */}
        <div className="lg:col-span-2">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-zinc-900/50 backdrop-blur-xl border border-white/5 rounded-3xl p-8 lg:p-10"
          >
            <div className="flex items-center justify-between mb-10">
              <div>
                <h1 className="text-3xl font-black text-white tracking-tighter uppercase mb-2">Profile Settings</h1>
                <p className="text-zinc-500 text-sm">Update your account details and preferences</p>
              </div>
            </div>

            <AnimatePresence mode="wait">
              {message.text && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className={`mb-8 p-4 rounded-xl flex items-center gap-3 text-sm font-bold ${
                    message.type === 'success' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'
                  }`}
                >
                  {message.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                  {message.text}
                </motion.div>
              )}
            </AnimatePresence>

            <form onSubmit={handleUpdateProfile} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Username */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Username</label>
                  <div className="relative group">
                    <input 
                      type="text" 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full bg-black border border-white/5 rounded-xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all text-sm font-medium"
                    />
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-emerald-500 transition-colors" />
                  </div>
                </div>

                {/* Birth Date */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Date of Birth</label>
                  <div className="relative group">
                    <input 
                      type="date" 
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="w-full bg-black border border-white/5 rounded-xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all text-sm font-medium [color-scheme:dark]"
                    />
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-emerald-500 transition-colors" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* New Password */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">New Password (Optional)</label>
                  <div className="relative group">
                    <input 
                      type="password" 
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-black border border-white/5 rounded-xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all text-sm"
                    />
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-emerald-500 transition-colors" />
                  </div>
                </div>

                {/* Confirm Password */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest ml-1">Confirm New Password</label>
                  <div className="relative group">
                    <input 
                      type="password" 
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full bg-black border border-white/5 rounded-xl py-3.5 pl-11 pr-4 text-white focus:outline-none focus:border-emerald-500/50 transition-all text-sm"
                    />
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-emerald-500 transition-colors" />
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-white/5 flex items-center justify-between gap-4">
                <button 
                  type="submit" 
                  disabled={isLoading}
                  className="bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-black font-black py-4 px-8 rounded-2xl flex items-center gap-2 transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      SAVE CHANGES
                    </>
                  )}
                </button>
                
                <p className="text-zinc-500 text-xs text-right max-w-[200px]">
                  All changes will be applied instantly to your public profile.
                </p>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
