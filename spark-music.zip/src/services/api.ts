import { MostListenedResponse } from '../types';

export const getApiBaseUrl = (): string => {
  const directBase = localStorage.getItem('spark_api_base_url');
  if (directBase) return directBase.trim().replace(/\/+$/, '');

  const adminEndpoint = localStorage.getItem('spark_api_endpoint');
  if (adminEndpoint) {
    try {
      const url = new URL(adminEndpoint.trim());
      const parts = url.pathname.split('/');
      parts.pop(); // remove 'youtube_admin_insert.php' or similar
      url.pathname = parts.join('/');
      return url.toString().replace(/\/+$/, '');
    } catch (e) {
      // ignore
    }
  }

  return 'http://localhost/sparkmusicapi';
};

export const API_ENDPOINTS = {
  get TRACKS() { return `${getApiBaseUrl()}/tracks_api.php`; },
  get MAIN_TRENDS() { return `${getApiBaseUrl()}/mainpagecountrycodetrends.php`; },
  get CHECK_LIKE() { return `${getApiBaseUrl()}/check.php`; },
  get TOGGLE_LIKE() { return `${getApiBaseUrl()}/likes.php`; },
  get COMMENTS() { return `${getApiBaseUrl()}/comment.php`; },
  get LOGIN() { return `${getApiBaseUrl()}/login.php`; },
  get REGISTER() { return `${getApiBaseUrl()}/register.php`; },
  get SEARCH() { return `${getApiBaseUrl()}/search.php`; },
  get ARTIST_PROFILE() { return `${getApiBaseUrl()}/songerprofile.php`; },
  get UPDATE_USER() { return `${getApiBaseUrl()}/update_user.php`; },
  get ARTIST_MOST_LISTENED() { return `${getApiBaseUrl()}/playlists_artistmostlistened.php`; },
  get ADD_PLAYLIST() { return `${getApiBaseUrl()}/add_playlist.php`; },
};

/**
 * Universal fetch wrapper for Spark Music API
 */
async function apiFetch(endpoint: string, params: Record<string, string | number | boolean> = {}, options: RequestInit = {}) {
  const url = new URL(endpoint);
  Object.keys(params).forEach(key => url.searchParams.append(key, params[key].toString()));
  
  const isGet = !options.method || options.method.toUpperCase() === 'GET';
  
  const response = await fetch(url.toString(), {
    ...options,
    headers: {
      ...(isGet ? {} : { 'Content-Type': 'application/json' }),
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }

  return response.json();
}

export const musicApi = {
  // Tracks & Trends
  getTracks: (country?: string) => 
    apiFetch(API_ENDPOINTS.TRACKS, country ? { country } : {}),
    
  getMainTrends: () => 
    apiFetch(API_ENDPOINTS.MAIN_TRENDS),

  // Search
  search: (query: string) =>
    apiFetch(API_ENDPOINTS.SEARCH, { q: query }),

  // Artist
  getArtistProfile: (artistName: string) =>
    apiFetch(API_ENDPOINTS.ARTIST_PROFILE, { q: artistName }),

  getMostListenedArtists: (country?: string): Promise<MostListenedResponse> =>
    apiFetch(API_ENDPOINTS.ARTIST_MOST_LISTENED, country ? { country } : {}),

  // Likes
  checkLikeStatus: (musicId: string, username: string) => 
    apiFetch(API_ENDPOINTS.CHECK_LIKE, { music_id: musicId, username }),
    
  toggleLike: (musicId: string, username: string) => 
    apiFetch(API_ENDPOINTS.TOGGLE_LIKE, { music_id: musicId, username }),

  // Comments
  getComments: (musicId: string, username?: string) => 
    apiFetch(API_ENDPOINTS.COMMENTS, { 
      music_id: musicId, 
      show_comments: 'true',
      ...(username ? { username } : {})
    }),
    
  addComment: (musicId: string, username: string, comment: string) => 
    apiFetch(API_ENDPOINTS.COMMENTS, { 
      music_id: musicId, 
      username: username, 
      comment: comment 
    }),
    
  deleteComment: (musicId: string, username: string) => 
    apiFetch(API_ENDPOINTS.COMMENTS, { 
      music_id: musicId, 
      username: username, 
      delete: 'true' 
    }),

  // Auth
  login: (credentials: any) => 
    fetch(API_ENDPOINTS.LOGIN, {
      method: 'POST',
      body: JSON.stringify(credentials)
    }).then(res => res.json()),

  register: (data: any) => 
    fetch(API_ENDPOINTS.REGISTER, {
      method: 'POST',
      body: JSON.stringify(data)
    }).then(res => res.json()),

  updateUser: (data: any) =>
    fetch(API_ENDPOINTS.UPDATE_USER, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    }).then(res => res.json()),

  addToPlaylist: (trackId: string, username: string, status?: string) => {
    const params: Record<string, string> = { user: username, trackid: trackId };
    if (status) {
      params.status = status;
    }
    return apiFetch(API_ENDPOINTS.ADD_PLAYLIST, params);
  },
};
