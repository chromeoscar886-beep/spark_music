import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, UserX } from 'lucide-react';
import { getApiBaseUrl } from '../services/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (user: User, token: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [blockReason, setBlockReason] = useState<string | null>(null);
  const [accountDeletedReason, setAccountDeletedReason] = useState<string | null>(null);

  useEffect(() => {
    const savedToken = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (savedToken && savedUser) {
      try {
        setToken(savedToken);
        setUser(JSON.parse(savedUser));
      } catch (err) {
        console.error('Failed to parse saved user:', err);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
    setIsReady(true);
  }, []);

  const login = (userData: User, userToken: string) => {
    setUser(userData);
    setToken(userToken);
    localStorage.setItem('token', userToken);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  };

  // Background check script to query user status every 30 seconds
  useEffect(() => {
    if (!user || !user.username) {
      return;
    }

    const checkUserStatus = async () => {
      try {
        const usernameParam = encodeURIComponent(user.username);
        const res = await fetch(`${getApiBaseUrl()}/process.php?username=${usernameParam}`);
        if (res.ok) {
          const data = await res.json();
          
          // Check if user is deleted or not found
          const isDeletedResponse = 
            (data && data.status === 'error' && data.user_exists === false) ||
            (data && data.user_exists === false) ||
            (data && data.message && data.message.toLowerCase().includes('deleted'));

          if (isDeletedResponse) {
            setAccountDeletedReason(
              (data && data.message) || `The account for user "${user.username}" was deleted or not found on the database.`
            );
            
            // Clear standard sessions & tokens immediately
            logout();
            
            // Wipe active browser cookies completely
            document.cookie.split(";").forEach((c) => {
              document.cookie = c
                .replace(/^ +/, "")
                .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
            });

            // Erase sessionStorage
            sessionStorage.clear();
            return;
          }

          // Check if user_status indicates user is blocked ("1" implies block, "0" is normal/active)
          if (data && String(data.user_status) === '1') {
            setBlockReason(
              `Administrative notice: The user account ${user.username} has been locked and placed under restriction.`
            );
            
            // Clear standard sessions & tokens immediately
            logout();
            
            // Wipe active browser cookies completely
            document.cookie.split(";").forEach((c) => {
              document.cookie = c
                .replace(/^ +/, "")
                .replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
            });

            // Erase sessionStorage
            sessionStorage.clear();
          }
        }
      } catch (err) {
        console.warn('Background status tracking connector offline:', err);
      }
    };

    // Run verification on mount
    checkUserStatus();

    // Query server health status every 30 seconds
    const interval = setInterval(checkUserStatus, 30000);

    return () => clearInterval(interval);
  }, [user]);

  if (!isReady) return null;

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isAuthenticated: !!token }}>
      {children}
      
      <AnimatePresence>
        {blockReason && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-xl">
            <motion.div 
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="w-full max-w-sm bg-zinc-900 border border-rose-500/30 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-[0_0_60px_rgba(244,63,94,0.15)] text-center space-y-6"
            >
              {/* Radial amber/rose glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-rose-500/10 rounded-full blur-[60px] pointer-events-none" />

              {/* Alert Icon Display */}
              <div className="relative flex justify-center">
                <div className="relative flex items-center justify-center w-14 h-14 rounded-full bg-rose-500/10 text-rose-500 border border-rose-500/20">
                  <ShieldAlert className="w-7 h-7" />
                </div>
              </div>

              {/* Typography Block */}
              <div className="space-y-1.5">
                <span className="text-[9px] font-black tracking-[0.2em] text-rose-500 uppercase font-mono">
                  Access Terminated
                </span>
                <h3 className="text-lg font-black text-white tracking-tight uppercase">
                  Account is Blocked
                </h3>
                <p className="text-xs text-zinc-400 font-sans leading-relaxed">
                  The database returned a locked session rule. You can no longer access Spark Music player, playlists, or analytics under this identity.
                </p>
              </div>

              {/* Context notification */}
              <div className="bg-black/40 border border-white/5 p-3.5 rounded-xl text-left">
                <div className="text-[8px] font-mono font-black text-zinc-500 uppercase tracking-widest mb-1">
                  Incident details
                </div>
                <div className="text-xs text-zinc-300 leading-relaxed font-sans font-medium">
                  {blockReason}
                </div>
              </div>

              {/* Closure button */}
              <button
                onClick={() => setBlockReason(null)}
                className="w-full bg-rose-600 hover:bg-rose-500 text-white text-xs uppercase font-extrabold tracking-widest py-3 px-6 rounded-xl transition-all active:scale-[0.97] shadow-lg shadow-rose-600/15 cursor-pointer"
              >
                Acknowledge & Exit
              </button>
            </motion.div>
          </div>
        )}

        {accountDeletedReason && (
          <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-zinc-950/85 backdrop-blur-xl">
            <motion.div 
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="w-full max-w-sm bg-zinc-900 border border-red-500/40 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-[0_0_60px_rgba(239,68,68,0.2)] text-center space-y-6"
            >
              {/* Radial red glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-red-500/10 rounded-full blur-[60px] pointer-events-none" />

              {/* Account Deleted Icon */}
              <div className="relative flex justify-center">
                <div className="relative flex items-center justify-center w-14 h-14 rounded-full bg-red-500/10 text-red-500 border border-red-500/20 animate-pulse">
                  <UserX className="w-7 h-7" />
                </div>
              </div>

              {/* Typography Block */}
              <div className="space-y-1.5">
                <span className="text-[9px] font-black tracking-[0.22em] text-red-500 uppercase font-mono">
                  Database Notice
                </span>
                <h3 className="text-lg font-black text-white tracking-tight uppercase">
                  Account Was Deleted
                </h3>
                <p className="text-xs text-zinc-400 font-sans leading-relaxed">
                  Your registration has been removed or could not be found within the server database directory. All session profiles have been wiped.
                </p>
              </div>

              {/* Detailed reason block */}
              <div className="bg-black/45 border border-white/5 p-3.5 rounded-xl text-left">
                <div className="text-[8px] font-mono font-black text-zinc-500 uppercase tracking-widest mb-1">
                  Server Message
                </div>
                <div className="text-xs text-red-400/90 leading-relaxed font-sans font-medium">
                  {accountDeletedReason}
                </div>
              </div>

              {/* Closure button */}
              <button
                onClick={() => setAccountDeletedReason(null)}
                className="w-full bg-red-600 hover:bg-red-500 text-white text-xs uppercase font-extrabold tracking-widest py-3 px-6 rounded-xl transition-all active:scale-[0.97] shadow-lg shadow-red-600/15 cursor-pointer"
              >
                Accept & Dismiss
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
