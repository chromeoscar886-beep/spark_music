import React, { createContext, useContext, useState, useRef, useEffect } from 'react';
import YouTube from 'react-youtube';
import { Track } from '../types';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { musicApi } from '../services/api';

interface PlayerContextType {
  currentTrack: Track | null;
  playing: boolean;
  volume: number;
  muted: boolean;
  played: number;
  duration: number;
  setTrack: (track: Track) => void;
  togglePlay: () => void;
  setVolume: (v: number) => void;
  setMuted: (m: boolean) => void;
  seekTo: (played: number) => void;
  allTracks: Track[];
  setAllTracks: (tracks: Track[]) => void;
  navigateToTrack: (step: number) => void;
  isLiked: boolean;
  likesCount: string;
  toggleLike: () => Promise<void>;
  activeColor: string;
  activeColors: string[];
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

declare global {
  interface Window {
    onYouTubeIframeAPIReady: () => void;
    YT: any;
  }
}

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAuthenticated, token } = useAuth();
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [playing, setPlaying] = useState(false);
  const playingRef = useRef(false);

  useEffect(() => {
    playingRef.current = playing;
    if (!playing) userPausedRef.current = true;
    else userPausedRef.current = false;
  }, [playing]);

  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState('0');
  const [volume, setVolume] = useState(() => {
    const saved = localStorage.getItem('spark_volume');
    return saved ? parseFloat(saved) : 0.8;
  });
  const [muted, setMuted] = useState(false);
  const [played, setPlayed] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isSeeking, setIsSeeking] = useState(false);
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [activeColor, setActiveColor] = useState('#10b981');
  const [activeColors, setActiveColors] = useState<string[]>(['#10b981', '#6366f1', '#f43f5e', '#0ea5e9']);

  // Dynamically extract colors from the track high-res thumbnail
  useEffect(() => {
    if (!currentTrack) {
      setActiveColor('#10b981');
      setActiveColors(['#10b981', '#6366f1', '#f43f5e', '#0ea5e9']);
      return;
    }

    const fallback = getDeterministicFallbackColor(String(currentTrack.id));
    const fallbackColors = getDeterministicFallbackColors(String(currentTrack.id));
    
    // Set immediate beautiful matched fallbacks first to prevent any delay
    setActiveColor(fallback);
    setActiveColors(fallbackColors);

    const videoId = getYouTubeID(currentTrack.musiclink || '');
    const imgUrl = videoId 
      ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
      : currentTrack.musicimg;

    if (imgUrl) {
      let isMounted = true;
      extractColorsFromImage(imgUrl, fallbackColors)
        .then((extracted) => {
          if (isMounted) {
            setActiveColors(extracted);
            if (extracted.length > 0) {
              setActiveColor(extracted[0]);
            }
          }
        });
      return () => {
        isMounted = false;
      };
    }
  }, [currentTrack]);

  const playerRef = useRef<any>(null);
  const userPausedRef = useRef<boolean>(false);
  const seekingTimeoutRef = useRef<any>(null);

  // Sync volume to localStorage
  useEffect(() => {
    localStorage.setItem('spark_volume', volume.toString());
  }, [volume]);

  // Handle play/pause sync from outer app state to raw player instance
  useEffect(() => {
    if (playerRef.current && typeof playerRef.current.getPlayerState === 'function') {
      try {
        const state = playerRef.current.getPlayerState();
        if (playing && state !== 1 && state !== 3) {
          playerRef.current.playVideo();
        } else if (!playing && state === 1) {
          playerRef.current.pauseVideo();
        }
      } catch (e) {
        console.warn('[PlayerContext] playState sync error:', e);
      }
    }
  }, [playing]);

  // Handle volume/mute sync from outer app state to raw player instance
  useEffect(() => {
    if (playerRef.current) {
      try {
        if (typeof playerRef.current.setVolume === 'function') {
          playerRef.current.setVolume(volume * 100);
        }
        if (typeof playerRef.current.mute === 'function' && typeof playerRef.current.unMute === 'function') {
          if (muted) {
            playerRef.current.mute();
          } else {
            playerRef.current.unMute();
          }
        }
      } catch (e) {
        console.warn('[PlayerContext] volume/mute sync error:', e);
      }
    }
  }, [volume, muted]);

  // Update playback time position periodically when playing
  useEffect(() => {
    let timer: any;
    if (playing && !isSeeking) {
      timer = setInterval(() => {
        if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
          try {
            const currentTime = playerRef.current.getCurrentTime();
            const totalDuration = playerRef.current.getDuration();
            if (totalDuration > 0) {
              setDuration(totalDuration);
              setPlayed(currentTime / totalDuration);
            }
          } catch (e) {
            // ignore
          }
        }
      }, 500);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [playing, isSeeking, currentTrack]);

  // Media Session API Support
  const updateMediaSession = (track: Track | null) => {
    if (!track || !('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.metadata = new window.MediaMetadata({
        title: track.musicname,
        artist: track.artistname || track.channel_name,
        artwork: [
          { src: track.musicimg, sizes: '512x512', type: 'image/jpeg' }
        ]
      });

      navigator.mediaSession.setActionHandler('play', () => setPlaying(true));
      navigator.mediaSession.setActionHandler('pause', () => setPlaying(false));
      navigator.mediaSession.setActionHandler('previoustrack', () => navigateToTrack(-1));
      navigator.mediaSession.setActionHandler('nexttrack', () => navigateToTrack(1));
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined && playerRef.current && typeof playerRef.current.seekTo === 'function') {
          playerRef.current.seekTo(details.seekTime, true);
        }
      });
    } catch (e) {
      console.warn('[PlayerContext] Media Session error:', e);
    }
  };

  const handleSetTrack = (track: Track) => {
    setPlayed(0);
    setDuration(0);
    setCurrentTrack(track);
    setPlaying(true);
    userPausedRef.current = false;
    if (seekingTimeoutRef.current) {
      clearTimeout(seekingTimeoutRef.current);
      seekingTimeoutRef.current = null;
    }
    setIsSeeking(false);
    updateMediaSession(track);
  };

  const seekTo = (p: number) => {
    setIsSeeking(true);
    setPlayed(p);

    if (seekingTimeoutRef.current) {
      clearTimeout(seekingTimeoutRef.current);
    }

    if (playerRef.current && typeof playerRef.current.seekTo === 'function') {
      const time = p * duration;
      try {
        playerRef.current.seekTo(time, true);
      } catch (err) {
        console.warn('[PlayerContext] seekTo error:', err);
      }
    }

    seekingTimeoutRef.current = setTimeout(() => {
      setIsSeeking(false);
      seekingTimeoutRef.current = null;
    }, 800);
  };

  const navigateToTrack = (step: number) => {
    if (allTracks.length === 0 || !currentTrack) {
      console.warn('[PlayerContext] Cannot navigate: allTracks empty or no currentTrack');
      return;
    }
    
    const currentIndex = allTracks.findIndex(t => String(t.id) === String(currentTrack.id));
    console.log(`[PlayerContext] Current Index: ${currentIndex}, Step: ${step}, Total: ${allTracks.length}`);
    
    let nextIndex;
    if (currentIndex === -1) {
      nextIndex = step > 0 ? 0 : allTracks.length - 1;
    } else {
      nextIndex = currentIndex + step;
      if (nextIndex >= allTracks.length) nextIndex = 0;
      if (nextIndex < 0) nextIndex = allTracks.length - 1;
    }
    
    const nextTrack = allTracks[nextIndex];
    console.log(`[PlayerContext] Target Index: ${nextIndex}, Track ID: ${nextTrack.id}`);
    handleSetTrack(nextTrack);
    
    if (location.pathname.startsWith('/track/')) {
      navigate(`/track/${nextTrack.id}`, { state: { track: nextTrack }, replace: true });
    }
  };


  // Check like status whenever track or user changes
  useEffect(() => {
    const checkStatus = async () => {
      if (!currentTrack?.id || !user?.username) {
        setIsLiked(false);
        setLikesCount('0');
        return;
      }

      try {
        console.log(`[PlayerContext] Checking like status: music_id=${currentTrack.id}, username=${user.username}`);
        const data = await musicApi.checkLikeStatus(currentTrack.id, user.username);
        console.log('[PlayerContext] Check result:', data);
        
        if (data.status === 'success') {
          const val = data.is_liked;
          const serverLiked = (val === true || val === 'true' || val === 1 || val === '1' || val === 'yes');
          setIsLiked(serverLiked);
          setLikesCount(data.likes_count?.toString() || '0');
        }
      } catch (err) {
        console.error('[PlayerContext] Check status error:', err);
      }
    };
    checkStatus();
  }, [currentTrack?.id, user?.username]);

  const toggleLike = async () => {
    console.log('[PlayerContext] toggleLike triggered');
    
    if (!currentTrack?.id) {
      console.warn('[PlayerContext] No current track ID');
      return;
    }

    if (!user?.username) {
      console.warn('[PlayerContext] No username available, redirecting to login');
      if (!isAuthenticated) navigate('/login');
      return;
    }

    const prevLiked = isLiked;
    const prevCount = parseInt(likesCount) || 0;

    // Optimistic Update
    const nextLiked = !prevLiked;
    const nextCount = prevLiked ? Math.max(0, prevCount - 1) : (prevCount + 1);
    
    console.log(`[PlayerContext] Optimistic Update: ${prevLiked} -> ${nextLiked}`);
    setIsLiked(nextLiked);
    setLikesCount(nextCount.toString());

    try {
      console.log('[PlayerContext] Sending like request for:', currentTrack.id);
      await musicApi.toggleLike(currentTrack.id, user.username);
      
      console.log('[PlayerContext] Like request performed. Syncing status...');
      
      // Verification re-fetch
      const checkData = await musicApi.checkLikeStatus(currentTrack.id, user.username);
      
      if (checkData.status === 'success') {
        const val = checkData.is_liked;
        const serverLiked = (val === true || val === 'true' || val === 1 || val === '1' || val === 'yes');
        console.log('[PlayerContext] Sync result:', { serverLiked, count: checkData.likes_count });
        setIsLiked(serverLiked);
        setLikesCount(checkData.likes_count?.toString() || '0');
      }
    } catch (err) {
      console.error('[PlayerContext] Like toggle error:', err);
      // Revert on real error
      setIsLiked(prevLiked);
      setLikesCount(prevCount.toString());
    }
  };

  const YouTubeComponent = YouTube as any;

  const onPlayerReady = (event: any) => {
    playerRef.current = event.target;
    try {
      event.target.setVolume(volume * 100);
      try {
        if (typeof event.target.setPlaybackQuality === 'function') {
          event.target.setPlaybackQuality('tiny');
        }
      } catch (err) {
        // ignore
      }
      if (muted) {
        event.target.mute();
      } else {
        event.target.unMute();
      }
      if (playing) {
        event.target.playVideo();
      }
    } catch (e) {
      console.warn('[PlayerContext] player ready handler error:', e);
    }
  };

  const onPlayerStateChange = (event: any) => {
    const playerState = event.data;
    // 1 = PLAYING, 2 = PAUSED, 0 = ENDED
    if (playerState === 1) {
      setPlaying(true);
      const d = event.target.getDuration();
      if (d > 0) setDuration(d);
      try {
        if (typeof event.target.setPlaybackQuality === 'function') {
          event.target.setPlaybackQuality('tiny');
        }
      } catch (err) {
        // ignore
      }
    } else if (playerState === 2) {
      setPlaying(false);
    } else if (playerState === 0) {
      navigateToTrack(1);
    }
  };

  return (
    <PlayerContext.Provider value={{
      currentTrack, playing, volume, muted, played, duration,
      setTrack: handleSetTrack,
      togglePlay: () => setPlaying(!playing),
      setVolume, setMuted, seekTo,
      allTracks, setAllTracks, navigateToTrack,
      isLiked, likesCount, toggleLike,
      activeColor, activeColors
    }}>
      {children}
      <div 
        className="fixed bottom-4 right-4 z-[1000] overflow-hidden rounded bg-black pointer-events-none"
        style={{ 
          width: '1px', 
          height: '1px',
          opacity: 0
        }}
      >
        {currentTrack && (
          <YouTubeComponent
            key={getYouTubeID(currentTrack.musiclink) || ''}
            videoId={getYouTubeID(currentTrack.musiclink) || ''}
            opts={{
              height: '100%',
              width: '100%',
              playerVars: { 
                autoplay: 1,
                playsinline: 1,
                controls: 0,
                disablekb: 1,
                rel: 0,
                modestbranding: 1,
                iv_load_policy: 3,
                origin: window.location.origin,
                enablejsapi: 1
              }
            }}
            onReady={onPlayerReady}
            onStateChange={onPlayerStateChange}
            style={{ width: '100%', height: '100%' }}
          />
        )}
      </div>
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (!context) throw new Error('usePlayer must be used within PlayerProvider');
  return context;
}

function getYouTubeID(url: string) {
  const regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : null;
}

const COLORS = [
  '#10b981', // Emerald
  '#6366f1', // Indigo
  '#f43f5e', // Rose
  '#0ea5e9', // Sky
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#8b5cf6', // Violet
];

function getDeterministicFallbackColor(trackId: string): string {
  if (!trackId) return '#10b981';
  let hash = 0;
  for (let i = 0; i < trackId.length; i++) {
    hash = trackId.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % COLORS.length;
  return COLORS[index];
}

function getDeterministicFallbackColors(trackId: string): string[] {
  if (!trackId) return ['#10b981', '#6366f1', '#f43f5e', '#0ea5e9'];
  let hash = 0;
  for (let i = 0; i < trackId.length; i++) {
    hash = trackId.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % COLORS.length;
  const c1 = COLORS[index];
  const c2 = COLORS[(index + 1) % COLORS.length];
  const c3 = COLORS[(index + 2) % COLORS.length];
  const c4 = COLORS[(index + 3) % COLORS.length];
  return [c1, c2, c3, c4];
}

function extractColorsFromImage(imageUrl: string, fallbackColors: string[]): Promise<string[]> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = imageUrl;

    const timeout = setTimeout(() => {
      resolve(fallbackColors);
    }, 1200);

    img.onload = () => {
      clearTimeout(timeout);
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 16;
        canvas.height = 16;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(fallbackColors);
          return;
        }
        ctx.drawImage(img, 0, 0, 16, 16);
        const data = ctx.getImageData(0, 0, 16, 16).data;

        // Collect pixels that are in reasonable luma & saturation range
        const candidates: { r: number; g: number; b: number; sat: number; luma: number }[] = [];
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i+1];
          const b = data[i+2];
          const a = data[i+3];

          if (a < 200) continue;

          const maxVal = Math.max(r, g, b);
          const minVal = Math.min(r, g, b);
          const delta = maxVal - minVal;
          const saturation = maxVal === 0 ? 0 : delta / maxVal;
          const luma = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

          if (luma > 0.15 && luma < 0.85 && saturation > 0.15) {
            candidates.push({ r, g, b, sat: saturation, luma });
          }
        }

        // Sort candidates by saturation desc to get the most vibrant ones first
        candidates.sort((a, b) => b.sat - a.sat);

        const extracted: string[] = [];
        const extractedRGB: { r: number; g: number; b: number }[] = [];

        for (const cand of candidates) {
          // Check if this color is distinct enough from already extracted ones
          let isDistinct = true;
          for (const ext of extractedRGB) {
            const dist = Math.sqrt((cand.r - ext.r)**2 + (cand.g - ext.g)**2 + (cand.b - ext.b)**2);
            if (dist < 55) { // Threshold for distinction
              isDistinct = false;
              break;
            }
          }
          if (isDistinct) {
            extracted.push(rgbToHex(cand.r, cand.g, cand.b));
            extractedRGB.push({ r: cand.r, g: cand.g, b: cand.b });
            if (extracted.length >= 4) break;
          }
        }

        // Fill remaining slots if we couldn't find enough distinct vibrant colors
        if (extracted.length < 4) {
          // Add fallback colors that are not too close to what we already extracted
          for (const fallback of fallbackColors) {
            if (extracted.length >= 4) break;
            const fbRGB = hexToRgb(fallback);
            if (fbRGB) {
              let isDistinct = true;
              for (const ext of extractedRGB) {
                const dist = Math.sqrt((fbRGB.r - ext.r)**2 + (fbRGB.g - ext.g)**2 + (fbRGB.b - ext.b)**2);
                if (dist < 40) {
                  isDistinct = false;
                  break;
                }
              }
              if (isDistinct) {
                extracted.push(fallback);
                extractedRGB.push(fbRGB);
              }
            }
          }
        }

        // Final safety check: if we still have less than 4, pad with fallbackColors directly
        while (extracted.length < 4) {
          const nextFallback = fallbackColors[extracted.length] || fallbackColors[0];
          extracted.push(nextFallback);
        }

        resolve(extracted);
      } catch (e) {
        resolve(fallbackColors);
      }
    };

    img.onerror = () => {
      clearTimeout(timeout);
      resolve(fallbackColors);
    };
  });
}

function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

function rgbToHex(r: number, g: number, b: number): string {
  const hex = (c: number) => {
    const s = Math.max(0, Math.min(255, c)).toString(16);
    return s.length === 1 ? '0' + s : s;
  };
  return `#${hex(r)}${hex(g)}${hex(b)}`;
}
